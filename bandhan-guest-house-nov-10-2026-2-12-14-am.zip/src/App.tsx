/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { 
  MapPin, Sparkles, Star, Wifi, Zap, Utensils, Shield, Phone, Mail, 
  Languages, Calendar, DollarSign, Users, Menu, X, ChevronDown, 
  Trash2, Receipt, ArrowRight, Bed, Maximize, Coffee, ArrowDown, HelpCircle,
  Car, MessageSquare, ExternalLink, Clock, ShieldCheck, HeartHandshake, Eye
} from "lucide-react";

import { 
  bandhanRooms, 
  bandhanAmenities, 
  savarAttractions, 
  genuineReviews, 
  bandhanFaqs, 
  hotelContact 
} from "./data";
import { Room } from "./types";
import SavarMap from "./components/SavarMap";
import BookingInquirySection from "./components/BookingInquirySection";
import ConciergeChat from "./components/ConciergeChat";
import RoomDetailsModal from "./components/RoomDetailsModal";
import BookingPolicySection from "./components/BookingPolicySection";
import PhotoGallerySection from "./components/PhotoGallerySection";
import MobileBottomNav from "./components/MobileBottomNav";

export default function App() {
  const [lang, setLang] = useState<"bn" | "en">("bn");
  const [selectedRoomId, setSelectedRoomId] = useState<string | null>(null);
  const [modalRoom, setModalRoom] = useState<Room | null>(null);
  const [activeFaq, setActiveFaq] = useState<string | null>("faq-policy-12h");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleLanguage = () => {
    setLang((prev) => (prev === "bn" ? "en" : "bn"));
  };

  const handleSelectRoomForBooking = (roomId: string) => {
    setSelectedRoomId(roomId);
    if (modalRoom) {
      setModalRoom(null);
    }
    const element = document.getElementById("booking-inquiry-section");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleOpenRoomDetails = (room: Room) => {
    setModalRoom(room);
  };

  const scrollToBooking = () => {
    const el = document.getElementById("booking-inquiry-section");
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div className="min-h-screen bg-[#FDFCF9] font-sans text-stone-900 selection:bg-amber-100 selection:text-amber-900 pb-16 sm:pb-0 relative">
      
      {/* Top Notice Header bar */}
      <div className="bg-[#1C1917] text-[#FAF8F5] py-2 px-4 shadow-inner text-[11px] md:text-xs border-b border-stone-800">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-2">
          
          <div className="flex items-center gap-3 md:gap-4 flex-wrap justify-center sm:justify-start">
            <span className="flex items-center gap-1.5 text-amber-400 font-semibold">
              <Sparkles className="w-3.5 h-3.5 animate-pulse" />
              <span>
                {lang === "bn" 
                  ? "বন্ধন গেস্ট হাউস (সি.আর.পি) — সাভারে প্রিমিয়াম এবং আরামদায়ক আবাসন" 
                  : "Bandhan Guest House (CRP) — Premium & Cozy Stay in Savar"}
              </span>
            </span>
            <span className="hidden md:inline text-stone-600">|</span>
            <a 
              href={hotelContact.mapsUrl} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="hidden lg:flex items-center gap-1 text-stone-300 hover:text-amber-400 transition-colors"
              title="Open location on Google Maps"
            >
              <MapPin className="w-3 h-3 text-amber-500" />
              <span>{hotelContact.addressBn} ({lang === "bn" ? "ম্যাপ দেখুন" : "View Map"})</span>
            </a>
          </div>
          
          <div className="flex items-center gap-2 sm:gap-4 font-mono font-medium flex-wrap justify-center">
            {/* Manager Contact */}
            <a 
              href={`tel:${hotelContact.phone}`} 
              className="flex items-center gap-1 text-amber-400 hover:text-amber-300 transition-colors text-[11px] md:text-xs font-semibold"
              title="Call Manager Shuvo"
            >
              <Phone className="w-3.5 h-3.5 text-amber-500" />
              <span>{lang === "bn" ? hotelContact.managerBn : hotelContact.managerEn}</span>
            </a>

            <span className="text-stone-600 hidden sm:inline">•</span>

            {/* WhatsApp Booking */}
            <a
              href={`https://wa.me/${hotelContact.whatsappClean}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-500 text-white text-[10.5px] px-2.5 py-0.5 rounded-full transition-colors font-sans font-semibold"
              title="Chat on WhatsApp with Manager"
            >
              <MessageSquare className="w-3 h-3 fill-white" />
              <span>WhatsApp {hotelContact.phone}</span>
            </a>
            
            {/* Language Switcher */}
            <button
              onClick={toggleLanguage}
              id="lang-switcher-top"
              className="bg-stone-800 hover:bg-stone-700 text-amber-400 hover:text-amber-300 text-[10.5px] px-2.5 py-0.5 rounded-full border border-stone-700 cursor-pointer flex items-center gap-1.5 transition-colors uppercase font-sans font-semibold"
              aria-label="Toggle Language"
            >
              <Languages className="w-3 h-3" />
              <span>{lang === "bn" ? "English" : "বাংলা"}</span>
            </button>
          </div>

        </div>
      </div>

      {/* Main Luxury Header Navigation */}
      <header className="sticky top-0 z-40 bg-[#FDFCF9]/95 backdrop-blur-md transition duration-300 shadow-xs border-b border-[#E7DDCB]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex justify-between items-center">
          
          {/* Logo & Branding - Displaying the Authentic Bandhan Hotel CRP Crest */}
          <a href="#hero-section" className="flex items-center gap-3 group">
            <img
              src={hotelContact.logoUrl}
              alt="Bandhan Guest House CRP Official Logo"
              className="w-11 h-11 sm:w-12 sm:h-12 rounded-full object-cover shadow-md border-2 border-amber-400 group-hover:scale-105 transition-transform shrink-0"
            />
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="font-serif text-base sm:text-lg md:text-xl font-bold tracking-tight text-stone-900 group-hover:text-[#B45309] transition-colors leading-tight">
                  {lang === "bn" ? hotelContact.nameBn : hotelContact.nameEn}
                </h1>
              </div>
              <p className="text-[10px] sm:text-xs text-stone-600 tracking-wide font-sans leading-none mt-1">
                {lang === "bn" ? hotelContact.addressBn : hotelContact.addressEn}
              </p>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden xl:flex items-center gap-6 text-xs md:text-sm font-medium text-stone-700">
            <a href="#hero-section" className="hover:text-[#B45309] transition">{lang === "bn" ? "হোম" : "Home"}</a>
            <a href="#about-section" className="hover:text-[#B45309] transition">{lang === "bn" ? "আমাদের সম্পর্কে" : "About Us"}</a>
            <a href="#rooms-section" className="hover:text-[#B45309] transition">{lang === "bn" ? "রুমসমূহ ও ভাড়া" : "Rooms & Rates"}</a>
            <a href="#policy-section" className="hover:text-[#B45309] transition">{lang === "bn" ? "১২ ঘণ্টার পলিসি" : "12h Policy"}</a>
            <a href="#amenities-section" className="hover:text-[#B45309] transition">{lang === "bn" ? "সুবিধাসমূহ" : "Facilities"}</a>
            <a href="#gallery-section" className="hover:text-[#B45309] transition">{lang === "bn" ? "ফটো গ্যালারি" : "Gallery"}</a>
            <a href="#reviews-section" className="hover:text-[#B45309] transition">{lang === "bn" ? "রিভিউ" : "Reviews"}</a>
            <a href="#savar-map-section" className="hover:text-[#B45309] transition">{lang === "bn" ? "লোকেশন" : "Location"}</a>
            <a href="#faq-section" className="hover:text-[#B45309] transition">{lang === "bn" ? "জিজ্ঞাসা" : "FAQs"}</a>
          </nav>

          {/* Desktop Right Actions */}
          <div className="hidden lg:flex items-center gap-3">
            <a
              href={`https://wa.me/${hotelContact.whatsappClean}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 bg-emerald-700 hover:bg-emerald-600 text-white px-3.5 py-2 rounded-xl text-xs font-semibold transition shadow-xs"
            >
              <MessageSquare className="w-3.5 h-3.5 fill-white" />
              <span>WhatsApp</span>
            </a>

            <a
              href="#booking-inquiry-section"
              className="bg-[#B45309] hover:bg-[#92400E] text-white px-4 py-2 rounded-xl text-xs font-semibold cursor-pointer shadow-xs transition duration-200"
            >
              {lang === "bn" ? "এখনই বুকিং করুন" : "Book Room Now"}
            </a>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            id="mobile-drawer-toggle"
            className="xl:hidden p-2 text-stone-800 hover:bg-stone-100 rounded-xl cursor-pointer"
            aria-label="Toggle Navigation Drawer"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation Drawer popup */}
        {mobileMenuOpen && (
          <div className="xl:hidden bg-white border-b border-[#E7DDCB] px-6 py-6 space-y-4 animate-fade-in-down shadow-xl">
            <div className="flex flex-col gap-3 font-medium text-stone-700 text-sm">
              <a href="#hero-section" onClick={() => setMobileMenuOpen(false)} className="hover:text-[#B45309] py-1">{lang === "bn" ? "হোম" : "Home"}</a>
              <a href="#about-section" onClick={() => setMobileMenuOpen(false)} className="hover:text-[#B45309] py-1">{lang === "bn" ? "আমাদের সম্পর্কে" : "About Us"}</a>
              <a href="#rooms-section" onClick={() => setMobileMenuOpen(false)} className="hover:text-[#B45309] py-1">{lang === "bn" ? "রুমসমূহ ও ভাড়া" : "Rooms & Rates"}</a>
              <a href="#policy-section" onClick={() => setMobileMenuOpen(false)} className="hover:text-[#B45309] py-1">{lang === "bn" ? "১২ ঘণ্টার বুকিং নীতিমালা" : "12-Hour Stay Policy"}</a>
              <a href="#amenities-section" onClick={() => setMobileMenuOpen(false)} className="hover:text-[#B45309] py-1">{lang === "bn" ? "রুমের সুবিধাসমূহ" : "Room Facilities"}</a>
              <a href="#gallery-section" onClick={() => setMobileMenuOpen(false)} className="hover:text-[#B45309] py-1">{lang === "bn" ? "ফটো গ্যালারি" : "Photo Gallery"}</a>
              <a href="#reviews-section" onClick={() => setMobileMenuOpen(false)} className="hover:text-[#B45309] py-1">{lang === "bn" ? "অতিথিদের রিভিউ" : "Guest Reviews"}</a>
              <a href="#savar-map-section" onClick={() => setMobileMenuOpen(false)} className="hover:text-[#B45309] py-1">{lang === "bn" ? "লোকেশন ও যাতায়াত" : "Location & Transit"}</a>
              <a href="#faq-section" onClick={() => setMobileMenuOpen(false)} className="hover:text-[#B45309] py-1">{lang === "bn" ? "সাধারণ প্রশ্নাবলী" : "FAQs"}</a>
              <a href="#contact-section" onClick={() => setMobileMenuOpen(false)} className="hover:text-[#B45309] py-1">{lang === "bn" ? "যোগাযোগ" : "Contact Us"}</a>
            </div>

            <div className="h-px bg-stone-100 my-2" />

            <div className="flex gap-2">
              <a
                href={`tel:${hotelContact.phone}`}
                className="flex-1 bg-stone-900 text-white text-center py-2.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5"
              >
                <Phone className="w-3.5 h-3.5 text-amber-400" />
                <span>{lang === "bn" ? "কল করুন" : "Call"}</span>
              </a>
              <a
                href={`https://wa.me/${hotelContact.whatsappClean}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 bg-emerald-600 text-white text-center py-2.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5"
              >
                <MessageSquare className="w-3.5 h-3.5 fill-white" />
                <span>WhatsApp</span>
              </a>
            </div>

            <a
              href="#booking-inquiry-section"
              onClick={() => setMobileMenuOpen(false)}
              className="block w-full bg-[#B45309] text-white text-center py-3 rounded-xl text-xs font-bold shadow-xs hover:bg-[#92400E] transition"
            >
              {lang === "bn" ? "এখনই বুকিং করুন" : "Book Room Now"}
            </a>
          </div>
        )}
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-16 sm:space-y-20">
        
        {/* 2. Professional Hero Section */}
        <section id="hero-section" className="relative rounded-2xl md:rounded-3xl overflow-hidden bg-stone-950 text-white min-h-[500px] md:min-h-[580px] flex items-center shadow-xl scroll-mt-24">
          
          {/* Background image: Real Bandhan Guest House CRP Reception */}
          <div className="absolute inset-0 z-0">
            <img
              src="/assets/aistudio/Warm_Bandhan_Guest_House_Reception_2bbcbd0c.png"
              alt="Bandhan Guest House (CRP) Reception & Front Desk"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover opacity-40 sm:opacity-45 scale-102 transition-transform duration-700 object-center"
            />
            {/* Elegant dark radial and linear gradients for text contrast */}
            <div className="absolute inset-0 bg-gradient-to-r from-stone-950 via-stone-950/90 to-stone-950/60" />
            <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-transparent to-stone-950/30" />
          </div>

          <div className="relative z-10 w-full px-6 sm:px-10 md:px-14 py-10 sm:py-14 flex flex-col lg:flex-row items-center justify-between gap-8 sm:gap-10">
            
            {/* Left Content Column */}
            <div className="w-full lg:max-w-2xl xl:max-w-3xl space-y-6 sm:space-y-8">
              {/* Branding Pill with Official Crest */}
              <div className="inline-flex items-center gap-2.5 bg-amber-500/15 border border-amber-500/30 px-4 py-1.5 rounded-full text-amber-300 font-semibold text-xs tracking-wider">
                <img 
                  src={hotelContact.logoUrl} 
                  alt="Logo" 
                  className="w-5 h-5 rounded-full object-cover border border-amber-400"
                />
                <span>
                  {lang === "bn" ? "বন্ধন গেস্ট হাউস (সি.আর.পি) • সাভার" : "Bandhan Guest House (CRP) • Savar"}
                </span>
              </div>

              {/* Required Headline */}
              <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold leading-[1.15] tracking-tight text-[#FDFCF7]">
                {lang === "bn" ? (
                  <>
                    সাভারে প্রিমিয়াম এবং <span className="text-amber-400 block sm:inline">আরামদায়ক আবাসন</span>
                  </>
                ) : (
                  <>
                    Premium & Comfortable <span className="text-amber-400">Hospitality in Savar</span>
                  </>
                )}
              </h2>

              {/* Short attractive description */}
              <p className="text-stone-300 text-sm sm:text-base md:text-lg max-w-2xl leading-relaxed">
                {lang === "bn" ? (
                  "সাভার আরিচা হাইওয়ে, সি.আর.পি ও শিমুলতলার মনোরম পরিবেশে অবস্থিত বন্ধন গেস্ট হাউস (সি.আর.পি)। আধুনিক শীতাতপ নিয়ন্ত্রিত এসি ও সাশ্রয়ী নন-এসি রুম, ২৪/৭ বিদ্যুৎ ব্যাকআপ, সর্বোচ্চ নিরাপত্তা ও ১২ ঘণ্টার স্পেশাল প্যাকেজ নিয়ে আমরা প্রস্তুত। সরাসরি যোগাযোগ: 01957203424 -শুভ (ম্যানেজার)।"
                ) : (
                  "Located on Savar Aricha Highway, CRP, Shimultola, Savar. Bandhan Guest House (CRP) offers quiet, clean, and fully-equipped AC and Non-AC suites with 24/7 power backup, 12-hour tariffs, and dedicated management care."
                )}
              </p>

              {/* Action Buttons: Primary, Secondary, WhatsApp */}
              <div className="flex flex-col sm:flex-row flex-wrap gap-3 sm:gap-4 pt-2">
                {/* Primary button: "রুমসমূহ ও ভাড়া দেখুন" */}
                <a
                  href="#rooms-section"
                  className="bg-[#B45309] hover:bg-[#92400E] text-[#FDFCF7] font-bold text-xs sm:text-sm px-6 py-3.5 rounded-xl transition duration-200 flex items-center justify-center gap-2 cursor-pointer shadow-lg active:scale-98"
                >
                  <span>{lang === "bn" ? "রুমসমূহ ও ভাড়া দেখুন" : "View Rooms & Rates"}</span>
                  <ArrowDown className="w-4 h-4 animate-bounce" />
                </a>

                {/* Secondary button: "এখনই বুকিং করুন" */}
                <a
                  href="#booking-inquiry-section"
                  className="bg-white/10 hover:bg-white/20 border border-white/20 text-[#FDFCF7] font-bold text-xs sm:text-sm px-6 py-3.5 rounded-xl transition duration-200 flex items-center justify-center gap-2 cursor-pointer backdrop-blur-xs active:scale-98"
                >
                  <span>{lang === "bn" ? "এখনই বুকিং করুন" : "Book Room Now"}</span>
                  <ArrowRight className="w-4 h-4" />
                </a>

                {/* WhatsApp booking button */}
                <a
                  href={`https://wa.me/${hotelContact.whatsappClean}?text=${encodeURIComponent(
                    lang === "bn"
                      ? "আসসালামু আলাইকুম শুভ ভাই, আমি বন্ধন গেস্ট হাউস (সি.আর.পি)-এ রুম বুকিং ও ভাড়া সম্পর্কে জানতে চাই।"
                      : "Hello Shuvo Bhai, I would like to inquire about booking a room at Bandhan Guest House (CRP)."
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm px-5 py-3.5 rounded-xl transition duration-200 flex items-center justify-center gap-2 cursor-pointer shadow-lg active:scale-98"
                >
                  <MessageSquare className="w-4 h-4 fill-white" />
                  <span>WhatsApp {hotelContact.phone}</span>
                </a>
              </div>

              {/* Clear Contact Information in Hero */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-6 border-t border-stone-800/80 max-w-2xl text-xs text-stone-300 font-mono">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-amber-500 shrink-0" />
                  <span className="truncate">{hotelContact.addressBn}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-amber-500 shrink-0" />
                  <span className="truncate">{hotelContact.managerBn}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-500 shrink-0" />
                  <span>{lang === "bn" ? "২৪/৭ যেকোনো সময় চেক-ইন" : "24/7 Any Time Check-in"}</span>
                </div>
              </div>
            </div>

            {/* Right Desktop Showcase Card: Clear High-Res Front Desk Preview */}
            <div className="hidden lg:block w-80 xl:w-96 shrink-0 animate-fade-in">
              <a
                href="#gallery-section"
                className="group block relative bg-gradient-to-b from-stone-900 to-stone-950 p-2.5 rounded-2xl border-2 border-amber-500/40 shadow-2xl hover:border-amber-400 transition-all hover:scale-[1.02]"
              >
                <div className="relative aspect-[4/3] rounded-xl overflow-hidden bg-stone-900">
                  <img
                    src="/assets/aistudio/Warm_Bandhan_Guest_House_Reception_2bbcbd0c.png"
                    alt="Bandhan Guest House Front Desk Reception"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-2.5 left-2.5 bg-stone-950/85 backdrop-blur-xs text-amber-300 border border-amber-500/40 text-[10.5px] font-semibold px-2.5 py-1 rounded-full flex items-center gap-1.5 shadow-sm">
                    <Sparkles className="w-3 h-3 text-amber-400" />
                    <span>{lang === "bn" ? "২৪/৭ ফ্রন্ট ডেস্ক ও রিসেপশন" : "24/7 Front Desk"}</span>
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-transparent to-transparent opacity-70 group-hover:opacity-40 transition-opacity" />
                </div>
                <div className="p-3 text-left space-y-1">
                  <div className="flex items-center justify-between">
                    <h4 className="font-serif text-sm font-bold text-white group-hover:text-amber-400 transition-colors">
                      {lang === "bn" ? "বন্ধন গেস্ট হাউস (সি.আর.পি)" : "Bandhan Guest House (CRP)"}
                    </h4>
                    <span className="text-[10px] text-amber-400/90 font-mono">
                      {lang === "bn" ? "গ্যালারি দেখুন" : "View Photo"}
                    </span>
                  </div>
                  <p className="text-[11px] text-stone-400 font-sans leading-tight">
                    {lang === "bn" ? "তত্ত্বাবধানে: শুভ (ম্যানেজার) • ফোন: 01957203424" : "On-site: Shuvo (Manager) • 01957203424"}
                  </p>
                </div>
              </a>
            </div>

          </div>
        </section>

        {/* About Us Section */}
        <section id="about-section" className="bg-[#FAF1E3]/50 border border-[#E7DDCB] rounded-2xl sm:rounded-3xl p-6 sm:p-10 space-y-6 scroll-mt-24">
          <div className="flex flex-col md:flex-row gap-8 items-center">
            
            <div className="w-full md:w-4/12 space-y-3 text-center md:text-left">
              <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-800 bg-white/80 px-3 py-1 rounded-full uppercase tracking-wider">
                <HeartHandshake className="w-3.5 h-3.5" />
                <span>{lang === "bn" ? "আমাদের পরিচিতি" : "About Bandhan"}</span>
              </div>
              <h3 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900 leading-snug">
                {lang === "bn" ? "সাভারে আপনার নিরাপদ ও আন্তরিক ঠিকানা" : "Your Peaceful Haven at Savar Aricha Highway"}
              </h3>
              <p className="text-xs sm:text-sm text-stone-600 font-medium">
                {lang === "bn" ? hotelContact.nameBn : hotelContact.nameEn}
              </p>
            </div>

            <div className="w-full md:w-8/12 text-stone-700 text-xs sm:text-sm md:text-base leading-relaxed space-y-4">
              <p>
                {lang === "bn" ? (
                  <span>
                    সাভারের শিমুলতলায় সিআরপি (CRP) এবং সাভার আরিচা হাইওয়ের সন্নিকটে অবস্থিত <strong>বন্ধন গেস্ট হাউস (সি.আর.পি)</strong>। চিকিৎসা, কর্পোরেট কাজ, ভর্তি পরীক্ষা বা পারিবারিক ভ্রমণের উদ্দেশ্যে সাভারে আগত মেহমানদের জন্য এটি একটি সম্পূর্ণ নিরাপদ, কোলাহলমুক্ত ও মার্জিত আবাসন। তত্ত্বাবধানে রয়েছেন <strong>{hotelContact.managerNameBn}</strong>।
                  </span>
                ) : (
                  <span>
                    Located on Savar Aricha Highway near CRP (Centre for the Rehabilitation of the Paralysed) and Savar Bus Stand at Shimultola, <strong>Bandhan Guest House (CRP)</strong> offers travelers a peaceful, secure, and respectful stay. Managed directly on-site by <strong>{hotelContact.managerNameEn}</strong>.
                  </span>
                )}
              </p>
              <p>
                {lang === "bn" ? (
                  <span>
                    আমাদের প্রধান আকর্ষণ হচ্ছে আমাদের <strong>১২ ঘণ্টার সুনির্দিষ্ট সাশ্রয়ী প্যাকেজ</strong>। দিনের বেলা স্বল্প সময়ের বিশ্রাম হোক কিংবা রাতের নির্বিঘ্ন ঘুম—প্রয়োজন অনুযায়ী এসি ও নন-এসি রুমের যেকোনোটি বেছে নিতে পারেন। প্রতিটি রুমে রয়েছে স্বাস্থ্যসম্মত পরিচ্ছন্নতা ও আন্তরিক কেয়ারটেকার সেবা।
                  </span>
                ) : (
                  <span>
                    We specialize in clear, budget-friendly <strong>12-hour flexible stay packages</strong>. Choose between modern AC suites and ventilated Non-AC rooms with guaranteed hygiene and polite caretaker support.
                  </span>
                )}
              </p>

              {/* Trust badges */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-2 text-xs font-semibold text-stone-800">
                <div className="bg-white p-2.5 rounded-xl border border-amber-200/60 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
                  <span>{lang === "bn" ? "১০০% নিরাপদ" : "100% Safe"}</span>
                </div>
                <div className="bg-white p-2.5 rounded-xl border border-amber-200/60 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-700 shrink-0" />
                  <span>{lang === "bn" ? "১২ ঘণ্টা প্যাকেজ" : "12h Package"}</span>
                </div>
                <div className="bg-white p-2.5 rounded-xl border border-amber-200/60 flex items-center gap-2">
                  <Wifi className="w-4 h-4 text-amber-700 shrink-0" />
                  <span>{lang === "bn" ? "ফ্রি ওয়াই-ফাই" : "Free Wi-Fi"}</span>
                </div>
                <div className="bg-white p-2.5 rounded-xl border border-amber-200/60 flex items-center gap-2">
                  <Zap className="w-4 h-4 text-amber-700 shrink-0" />
                  <span>{lang === "bn" ? "বিদ্যুৎ ব্যাকআপ" : "Power Backup"}</span>
                </div>
              </div>

            </div>

          </div>
        </section>

        {/* 3. Room Booking Section - Improved Cards with Photo Gallery & Verified Specs */}
        <section id="rooms-section" className="space-y-8 scroll-mt-24">
          <div className="text-center max-w-2xl mx-auto space-y-3">
            <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-800 bg-[#FAF1E3] px-3.5 py-1 rounded-full uppercase tracking-wider">
              <Bed className="w-3.5 h-3.5" />
              <span>{lang === "bn" ? "রুমসমূহ ও নির্ধারিত ভাড়া" : "Rooms & Verified Tariffs"}</span>
            </div>
            
            <h3 className="font-serif text-2xl sm:text-3xl md:text-4xl font-bold text-stone-900 leading-tight">
              {lang === "bn" ? "আপনার পছন্দের রুমটি বেছে নিন" : "Verified Rooms for Splendid Rest"}
            </h3>
            
            <p className="text-stone-600 text-xs sm:text-sm md:text-base">
              {lang === "bn" 
                ? "বাস্তব আলোকচিত্র ও যাচাইকৃত সুবিধাসহ এসি এবং নন-এসি রুম। কোনো লুকানো চার্জ নেই।" 
                : "Real room photographs with verified dimensions, amenities, and transparent day/night tariffs."}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {bandhanRooms.map((room) => (
              <div 
                key={room.id}
                className="bg-white border-2 border-[#E7DDCB] hover:border-[#B45309]/50 rounded-2xl sm:rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col group"
              >
                
                {/* Room card Actual Photograph */}
                <div className="relative aspect-[16/10] w-full overflow-hidden bg-stone-900">
                  <img
                    src={room.imageUrl}
                    alt={lang === "bn" ? room.nameBn : room.nameEn}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  
                  {/* Verified & Featured Badges */}
                  <div className="absolute top-4 left-4 flex flex-col gap-1.5">
                    {room.featured && (
                      <span className="bg-[#B45309] text-white text-[10px] uppercase font-bold tracking-wider px-3 py-1 rounded-full flex items-center gap-1 shadow-sm">
                        <Sparkles className="w-3 h-3 fill-white" />
                        <span>{lang === "bn" ? "জনপ্রিয় চয়েস" : "Most Popular"}</span>
                      </span>
                    )}
                    <span className="bg-stone-950/80 backdrop-blur-xs text-white text-[10px] font-mono px-2.5 py-0.5 rounded-md border border-stone-700">
                      {room.isSizeVerified ? (lang === "bn" ? "✓ সাইজ যাচাইকৃত" : "✓ Verified Size") : ""}
                    </span>
                  </div>

                  {/* Photo Gallery preview button on hover */}
                  <button
                    onClick={() => handleOpenRoomDetails(room)}
                    className="absolute top-4 right-4 bg-stone-900/80 hover:bg-stone-900 text-white text-[11px] font-medium px-3 py-1 rounded-full backdrop-blur-xs border border-stone-700 flex items-center gap-1 cursor-pointer transition"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>{lang === "bn" ? "গ্যালারি ও বিবরণ" : "Gallery & Details"}</span>
                  </button>

                  {/* Price Tag Overlay */}
                  <div className="absolute bottom-4 right-4 bg-stone-950/90 backdrop-blur-xs text-white px-3.5 py-1.5 rounded-xl border border-stone-800 font-mono flex flex-col items-end shadow-md">
                    <span className="text-[9px] text-amber-400 font-sans uppercase">
                      {lang === "bn" ? "১২ ঘণ্টা ডে স্টে" : "12h Day Stay"}
                    </span>
                    <span className="text-lg font-bold text-white">৳{room.dayStayPrice.toLocaleString()}</span>
                  </div>
                </div>

                {/* Room Details Body */}
                <div className="p-6 sm:p-7 flex-1 flex flex-col justify-between space-y-5">
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h4 className="font-serif text-xl sm:text-2xl font-bold text-stone-900 group-hover:text-[#B45309] transition-colors">
                          {lang === "bn" ? room.nameBn : room.nameEn}
                        </h4>
                        <p className="text-xs text-amber-800 font-medium mt-1">
                          {lang === "bn" ? room.taglineBn : room.taglineEn}
                        </p>
                      </div>
                    </div>

                    {/* Day and Night Rental Prices Box */}
                    <div className="mt-4 p-3.5 bg-[#FAF1E3] border border-amber-300/80 rounded-xl space-y-2">
                      <div className="flex justify-between items-center text-xs">
                        <span className="font-semibold text-stone-800 flex items-center gap-1">
                          <span>☀️ {lang === "bn" ? "ডে স্টে (১২ ঘণ্টা):" : "Day Stay (12 Hours):"}</span>
                        </span>
                        <span className="font-mono font-bold text-base text-[#B45309]">
                          ৳{room.dayStayPrice.toLocaleString()}
                        </span>
                      </div>
                      <div className="flex justify-between items-center text-xs border-t border-amber-200/60 pt-2">
                        <span className="font-semibold text-stone-800 flex items-center gap-1">
                          <span>🌙 {lang === "bn" ? "নাইট স্টে (রাত্রীযাপন):" : "Night Stay:"}</span>
                        </span>
                        <span className="font-mono font-bold text-base text-stone-900">
                          ৳{room.nightStayPrice.toLocaleString()}
                        </span>
                      </div>
                    </div>

                    {/* 12-Hour Booking Policy Highlight */}
                    <div className="mt-3 p-2.5 bg-stone-50 rounded-lg border border-stone-200/80 text-[11px] text-stone-600 flex items-start gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-amber-700 shrink-0 mt-0.5" />
                      <span>
                        <strong>{lang === "bn" ? "১২ ঘণ্টা পলিসি:" : "12h Policy:"}</strong> {lang === "bn" ? "বুকিংয়ের ১২ ঘণ্টার মধ্যে যতক্ষণই অবস্থান করুন, ভাড়া অপরিবর্তিত।" : "Tariff is fixed for 12 hours regardless of early check-out."}
                      </span>
                    </div>

                    {/* Meta Specs Grid */}
                    <div className="grid grid-cols-3 gap-2 border-y border-stone-100 my-4 py-3 text-[11px] font-mono text-stone-600">
                      <div className="flex flex-col items-center text-center">
                        <Bed className="w-4 h-4 text-amber-700 mb-1" />
                        <span className="text-stone-900 font-semibold">{lang === "bn" ? "বেড টাইপ" : "Bed Setup"}</span>
                        <span className="text-[9.5px] truncate max-w-[120px]">{lang === "bn" ? room.bedTypeBn : room.bedTypeEn}</span>
                      </div>
                      <div className="flex flex-col items-center text-center border-x border-stone-100">
                        <Users className="w-4 h-4 text-amber-700 mb-1" />
                        <span className="text-stone-900 font-semibold">{lang === "bn" ? "ধারণক্ষমতা" : "Capacity"}</span>
                        <span className="text-[9.5px]">{room.capacity} {lang === "bn" ? "জন মেহমান" : "Guests"}</span>
                      </div>
                      <div className="flex flex-col items-center text-center">
                        <Maximize className="w-4 h-4 text-amber-700 mb-1" />
                        <span className="text-stone-900 font-semibold">{lang === "bn" ? "রুম সাইজ" : "Room Area"}</span>
                        <span className="text-[9.5px] font-bold text-emerald-800">{room.sizeSft} Sq.Ft ({lang === "bn" ? "যাচাইকৃত" : "Verified"})</span>
                      </div>
                    </div>

                    {/* Available Facilities Checklist */}
                    <div className="space-y-1.5">
                      <span className="text-[11px] font-bold text-stone-800 block">
                        {lang === "bn" ? "উপলব্ধ সুযোগ-সুবিধা:" : "Available Facilities:"}
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {(lang === "bn" ? room.amenitiesBn : room.amenitiesEn).slice(0, 5).map((amenity, i) => (
                          <span key={i} className="text-[10px] text-stone-700 bg-stone-100 border border-stone-200 px-2 py-0.5 rounded-md flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
                            <span>{amenity}</span>
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Action Buttons: Details and Book Now */}
                  <div className="flex gap-2.5 pt-2">
                    <button
                      onClick={() => handleOpenRoomDetails(room)}
                      id={`view-details-${room.id}`}
                      className="flex-1 bg-stone-100 hover:bg-stone-200 text-stone-800 py-3 rounded-xl text-xs font-semibold cursor-pointer transition flex items-center justify-center gap-1.5 border border-stone-200"
                    >
                      <Eye className="w-3.5 h-3.5 text-stone-600" />
                      <span>{lang === "bn" ? "গ্যালারি ও বিস্তারিত" : "Photo Gallery"}</span>
                    </button>

                    <button
                      onClick={() => handleSelectRoomForBooking(room.id)}
                      id={`book-room-btn-${room.id}`}
                      className="flex-1.2 bg-[#B45309] hover:bg-[#92400E] text-white py-3 rounded-xl text-xs font-bold cursor-pointer transition duration-200 flex items-center justify-center gap-1.5 shadow-sm"
                    >
                      <span>{lang === "bn" ? "এই রুম বুক করুন" : "Book This Room"}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                </div>

              </div>
            ))}
          </div>

        </section>

        {/* 5. Booking Policy Section */}
        <BookingPolicySection lang={lang} />

        {/* Room Facilities Section */}
        <section id="amenities-section" className="space-y-8 scroll-mt-24">
          <div className="text-center max-w-2xl mx-auto space-y-3">
            <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-800 bg-[#FAF1E3] px-3.5 py-1 rounded-full uppercase tracking-wider">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>{lang === "bn" ? "অতিথিদের সুযোগ-সুবিধা" : "Guest Amenities"}</span>
            </div>
            <h3 className="font-serif text-2xl sm:text-3xl md:text-4xl font-bold text-stone-900 leading-tight">
              {lang === "bn" ? "নিখুঁত ও নির্ভরযোগ্য আতিথেয়তা" : "Verified Comfort & Security Features"}
            </h3>
            <p className="text-stone-600 text-xs sm:text-sm md:text-base">
              {lang === "bn" 
                ? "আমাদের প্রতিটি সুযোগ-সুবিধা নিয়মিত রক্ষণাবেক্ষণ করা হয় যেন আপনার অবস্থান হয় স্বস্তিদায়ক।" 
                : "Continuous high-speed broadband, 24/7 power, and sanitized bathrooms for complete peace of mind."}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {bandhanAmenities.map((item) => {
              let Icon = Wifi;
              if (item.id === "power") Icon = Zap;
              if (item.id === "security") Icon = Shield;
              if (item.id === "service") Icon = Clock;
              if (item.id === "hygiene") Icon = Sparkles;
              if (item.id === "dining") Icon = Utensils;

              return (
                <div 
                  key={item.id}
                  className="bg-white border border-[#E7DDCB] p-5 sm:p-6 rounded-2xl shadow-xs hover:border-[#B45309]/50 transition duration-200 flex items-start gap-4"
                >
                  <div className="p-3 bg-[#FAF1E3] rounded-xl text-[#B45309] shrink-0">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-serif text-base font-bold text-stone-900 mb-1">
                      {lang === "bn" ? item.nameBn : item.nameEn}
                    </h4>
                    <p className="text-stone-600 text-xs sm:text-sm leading-relaxed">
                      {lang === "bn" ? item.descriptionBn : item.descriptionEn}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* 7. Photo Gallery Section */}
        <PhotoGallerySection lang={lang} />

        {/* 4. Booking System Form & Instant Cost Calculator */}
        <BookingInquirySection 
          lang={lang} 
          selectedRoomId={selectedRoomId} 
          onClearRoomSelection={() => setSelectedRoomId(null)} 
        />

        {/* 7. Guest Reviews - Genuine Reviews Only */}
        <section id="reviews-section" className="bg-[#1C1917] text-white rounded-2xl sm:rounded-3xl p-6 sm:p-10 space-y-8 shadow-xl scroll-mt-24">
          <div className="text-center max-w-xl mx-auto space-y-3">
            <span className="text-[10px] bg-stone-800 text-amber-400 font-mono px-3 py-1 rounded-full uppercase tracking-widest font-semibold border border-stone-700">
              Verified Feedback
            </span>
            <h3 className="font-serif text-2xl sm:text-3xl font-bold text-[#FDFCF7]">
              {lang === "bn" ? "অতিথিদের বাস্তব অভিজ্ঞতা" : "Genuine Guest Experiences"}
            </h3>
            <p className="text-stone-400 text-xs sm:text-sm">
              {lang === "bn" 
                ? "সিআরপি চিকিৎসা ও সাভারে আগত সম্মানিত অতিথিদের মতামত।" 
                : "Authentic feedback from real guests who experienced Bandhan Guest House hospitality."}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {genuineReviews.map((rev) => (
              <div 
                key={rev.id}
                className="bg-stone-950/60 border border-stone-800 rounded-2xl p-5 sm:p-6 flex flex-col justify-between space-y-4 shadow-sm"
              >
                <div className="space-y-3">
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <Star key={s} className="w-3.5 h-3.5 fill-amber-400 stroke-amber-500" />
                    ))}
                  </div>
                  
                  <p className="text-stone-300 text-xs sm:text-sm italic leading-relaxed">
                    "{lang === "bn" ? rev.commentBn : rev.commentEn}"
                  </p>
                </div>

                <div className="pt-4 border-t border-stone-800/80 flex justify-between items-center text-xs">
                  <div>
                    <h5 className="font-semibold text-white">
                      {lang === "bn" ? rev.authorBn : rev.authorEn}
                    </h5>
                    <p className="text-stone-400 text-[10.5px]">
                      {lang === "bn" ? rev.roleBn : rev.roleEn}
                    </p>
                  </div>
                  <span className="text-[10px] text-stone-500 font-mono">
                    {lang === "bn" ? rev.dateBn : rev.dateEn}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* 6. Interactive Map & Surroundings */}
        <SavarMap lang={lang} />

        {/* 7. Frequently Asked Questions */}
        <section id="faq-section" className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start scroll-mt-24">
          
          <div className="lg:col-span-4 space-y-4">
            <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-800 bg-[#FAF1E3] px-3.5 py-1 rounded-full uppercase tracking-wider">
              <HelpCircle className="w-3.5 h-3.5" />
              <span>{lang === "bn" ? "সাধারণ জিজ্ঞাসাবলী" : "Frequently Asked Questions"}</span>
            </div>

            <h3 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900 leading-tight">
              {lang === "bn" ? "বুকিং ও অবস্থান সম্পর্কে প্রশ্নের উত্তর" : "Have Questions About Your Stay?"}
            </h3>

            <p className="text-stone-600 text-xs sm:text-sm leading-relaxed">
              {lang === "bn" 
                ? "১২ ঘণ্টার প্যাকেজ, চেক-ইন বা সিআরপি শিমুলতলার অবস্থান সংক্রান্ত তথ্যের জন্য নিচে ক্লিক করুন।" 
                : "Instant answers regarding 12-hour policies, check-in flexibility, and directions."}
            </p>

            <div className="bg-[#FAF8F5] border border-[#E7DDCB] p-5 rounded-2xl text-xs space-y-3 mt-4 text-stone-700">
              <span className="font-bold text-stone-900 block">{lang === "bn" ? "সরাসরি যোগাযোগ ও সহায়তা:" : "Direct Room Desk Hotline:"}</span>
              <div className="flex flex-col gap-2 pt-1 font-mono">
                <a href={`tel:${hotelContact.phone}`} className="inline-flex items-center gap-2 font-bold text-stone-900 hover:text-[#B45309]">
                  <Phone className="w-4 h-4 text-amber-700" />
                  <span>{hotelContact.phone}</span>
                </a>
                <a 
                  href={`https://wa.me/${hotelContact.whatsappClean}`} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="inline-flex items-center gap-2 font-bold text-emerald-700 hover:underline"
                >
                  <MessageSquare className="w-4 h-4 fill-emerald-600 text-emerald-600" />
                  <span>WhatsApp: {hotelContact.whatsapp}</span>
                </a>
              </div>
            </div>
          </div>

          <div className="lg:col-span-8 bg-white border border-[#E7DDCB] p-4 sm:p-6 rounded-2xl sm:rounded-3xl shadow-xs space-y-3">
            {bandhanFaqs.map((faq) => {
              const isActive = activeFaq === faq.id;
              return (
                <div 
                  key={faq.id}
                  className="border border-stone-200 rounded-xl overflow-hidden transition-colors"
                >
                  <button
                    onClick={() => setActiveFaq(isActive ? null : faq.id)}
                    className="w-full flex items-center justify-between text-left p-4 bg-[#FCFBF8] hover:bg-stone-50 transition-colors cursor-pointer"
                  >
                    <span className="font-semibold text-stone-900 text-xs sm:text-sm pr-4">
                      {lang === "bn" ? faq.questionBn : faq.questionEn}
                    </span>
                    <ChevronDown className={`w-4 h-4 text-stone-500 shrink-0 transition-transform duration-200 ${isActive ? "rotate-180" : ""}`} />
                  </button>

                  {isActive && (
                    <div className="p-4 bg-white text-stone-700 text-xs sm:text-sm leading-relaxed border-t border-stone-200 whitespace-pre-line animate-fade-in">
                      {lang === "bn" ? faq.answerBn : faq.answerEn}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

        </section>

        {/* 6. Contact and Location Section */}
        <section id="contact-section" className="bg-[#FAF1E3]/60 border border-[#E7DDCB] rounded-2xl sm:rounded-3xl p-6 sm:p-10 space-y-6 scroll-mt-24">
          <div className="text-center max-w-xl mx-auto space-y-2">
            <h3 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900">
              {lang === "bn" ? "যোগাযোগ ও সরাসরি লোকেশন" : "Contact & Visit Us"}
            </h3>
            <p className="text-stone-600 text-xs sm:text-sm">
              {lang === "bn" ? "যেকোনো বুকিং অনুসন্ধান বা সরাসরি উপস্থিতির জন্য আমাদের ঠিকানা" : "Reach out for reservation inquiries or transit directions."}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4">
            
            {/* Address */}
            <div className="bg-white border border-[#E7DDCB] p-6 rounded-2xl shadow-xs space-y-3 text-center sm:text-left">
              <div className="w-10 h-10 rounded-xl bg-amber-100 text-[#B45309] flex items-center justify-center mx-auto sm:mx-0">
                <MapPin className="w-5 h-5" />
              </div>
              <h4 className="font-serif font-bold text-stone-900 text-base">
                {lang === "bn" ? "গেস্ট হাউসের ঠিকানা" : "Guest House Address"}
              </h4>
              <p className="text-stone-800 text-xs sm:text-sm font-bold">
                {lang === "bn" ? hotelContact.nameBn : hotelContact.nameEn}
              </p>
              <p className="text-stone-700 text-xs leading-relaxed font-medium">
                {lang === "bn" ? hotelContact.addressBn : hotelContact.addressEn}<br />
                <span className="text-stone-500 font-normal">
                  {lang === "bn" ? "(ক্যাপ্টেন সামাদ টাওয়ার, লিফট-৫, সাভার বাসস্ট্যান্ড সংলগ্ন)" : "(Captain Samad Tower, Lift-5)"}
                </span>
              </p>
              <a 
                href={hotelContact.mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-xs text-[#B45309] font-semibold hover:underline pt-1"
              >
                <span>{lang === "bn" ? "গুগল ম্যাপে দেখুন" : "View on Google Maps"}</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            {/* Direct Phone / Manager */}
            <div className="bg-white border border-[#E7DDCB] p-6 rounded-2xl shadow-xs space-y-3 text-center sm:text-left">
              <div className="w-10 h-10 rounded-xl bg-amber-100 text-[#B45309] flex items-center justify-center mx-auto sm:mx-0">
                <Phone className="w-5 h-5" />
              </div>
              <h4 className="font-serif font-bold text-stone-900 text-base">
                {lang === "bn" ? "সরাসরি ফোন ও বুকিং" : "Direct Phone Contact"}
              </h4>
              <p className="text-stone-600 text-xs font-semibold">
                {lang === "bn" ? hotelContact.managerBn : hotelContact.managerEn}
              </p>
              <a 
                href={`tel:${hotelContact.phone}`}
                className="text-lg font-mono font-bold text-stone-900 hover:text-[#B45309] block transition"
              >
                {hotelContact.phone}
              </a>
              <a
                href={`tel:${hotelContact.phone}`}
                className="inline-flex items-center gap-1.5 text-xs bg-stone-900 hover:bg-[#B45309] text-white px-4 py-2 rounded-xl transition font-semibold"
              >
                <Phone className="w-3.5 h-3.5 text-amber-400" />
                <span>{lang === "bn" ? "কল দিন: শুভ (ম্যানেজার)" : "Call Manager Shuvo"}</span>
              </a>
            </div>

            {/* WhatsApp Contact */}
            <div className="bg-white border border-[#E7DDCB] p-6 rounded-2xl shadow-xs space-y-3 text-center sm:text-left">
              <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center mx-auto sm:mx-0">
                <MessageSquare className="w-5 h-5 fill-emerald-700 text-emerald-700" />
              </div>
              <h4 className="font-serif font-bold text-stone-900 text-base">
                {lang === "bn" ? "হোয়াটসঅ্যাপ চ্যাট ও বুকিং" : "WhatsApp Chat & Inquiry"}
              </h4>
              <p className="text-stone-600 text-xs font-semibold">
                {lang === "bn" ? hotelContact.managerBn : hotelContact.managerEn}
              </p>
              <a 
                href={`https://wa.me/${hotelContact.whatsappClean}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-lg font-mono font-bold text-emerald-700 hover:text-emerald-800 block transition"
              >
                {hotelContact.phone}
              </a>
              <a
                href={`https://wa.me/${hotelContact.whatsappClean}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-xs bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-xl transition font-semibold shadow-xs"
              >
                <MessageSquare className="w-3.5 h-3.5 fill-white" />
                <span>{lang === "bn" ? "হোয়াটসঅ্যাপে মেসেজ পাঠান" : "Chat on WhatsApp"}</span>
              </a>
            </div>

          </div>
        </section>

      </main>

      {/* Interactive Room Details Modal */}
      <RoomDetailsModal
        room={modalRoom}
        lang={lang}
        onClose={() => setModalRoom(null)}
        onBookNow={handleSelectRoomForBooking}
      />

      {/* Floating Concierge Chat */}
      <ConciergeChat lang={lang} />

      {/* Mobile Sticky Bottom Navigation (Phone, WhatsApp, Book Now) */}
      <MobileBottomNav 
        lang={lang} 
        onBookClick={scrollToBooking} 
      />

      {/* Footer */}
      <footer className="bg-[#1C1917] text-[#FAF8F5] border-t border-stone-800 mt-20 pt-16 pb-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 md:gap-12 mb-12">
          
          {/* Column 1: Brand Info */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <img
                src={hotelContact.logoUrl}
                alt="Bandhan Guest House Logo"
                className="w-12 h-12 rounded-full object-cover border-2 border-amber-400 shadow-md"
              />
              <div>
                <h4 className="font-serif text-lg font-bold text-white leading-tight">
                  {lang === "bn" ? hotelContact.nameBn : hotelContact.nameEn}
                </h4>
                <p className="text-[10px] text-amber-400 font-mono tracking-wider">
                  {hotelContact.addressBn}
                </p>
              </div>
            </div>
            
            <p className="text-stone-400 text-xs leading-relaxed font-light">
              {lang === "bn"
                ? "সাভার আরিচা হাইওয়ে, সি.আর.পি ও শিমুলতলার মনোরম পরিবেশে অবস্থিত বন্ধন গেস্ট হাউস (সি.আর.পি)। সার্বক্ষণিক দায়িত্বে: 01957203424 -শুভ (ম্যানেজার)।"
                : "Premium lodging at Savar Aricha Highway, CRP, Shimultola, Savar. Contact on-site: 01957203424 - Shuvo (Manager)."}
            </p>
          </div>

          {/* Column 2: Rooms */}
          <div>
            <h5 className="font-serif text-amber-400 text-xs uppercase tracking-wider mb-4 font-bold">
              {lang === "bn" ? "রুমসমূহ ও ভাড়া" : "Room Categories"}
            </h5>
            <ul className="space-y-2.5 text-xs text-stone-400">
              <li>
                <a href="#rooms-section" className="hover:text-white transition flex justify-between">
                  <span>{lang === "bn" ? "এসি রুম (AC Room)" : "AC Room"}</span>
                  <span className="font-mono text-amber-400">৳২,২০০ / ৳২,৪০০</span>
                </a>
              </li>
              <li>
                <a href="#rooms-section" className="hover:text-white transition flex justify-between">
                  <span>{lang === "bn" ? "নন-এসি রুম (Non-AC)" : "Non-AC Room"}</span>
                  <span className="font-mono text-amber-400">৳১,৫০০ / ৳১,৬০০</span>
                </a>
              </li>
              <li className="pt-2 text-[11px] text-stone-500">
                {lang === "bn" ? "*১২ ঘণ্টা প্যাকেজ ও নাইট স্টে অন্তর্ভুক্ত" : "*12h stay & night stay packages"}
              </li>
            </ul>
          </div>

          {/* Column 3: Contact & Location */}
          <div>
            <h5 className="font-serif text-amber-400 text-xs uppercase tracking-wider mb-4 font-bold">
              {lang === "bn" ? "যোগাযোগ ও হেল্পলাইন" : "Contacts & Booking"}
            </h5>
            <ul className="space-y-3 text-xs text-stone-400">
              <li className="flex items-start gap-2">
                <Phone className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                <div>
                  <a href={`tel:${hotelContact.phone}`} className="font-mono text-white hover:text-amber-400 font-semibold block">
                    {hotelContact.managerBn}
                  </a>
                  <span className="text-[10px] text-stone-500">{lang === "bn" ? "রুম বুকিং ও তথ্য" : "Booking Helpline"}</span>
                </div>
              </li>
              <li className="flex items-start gap-2">
                <MessageSquare className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <a 
                    href={`https://wa.me/${hotelContact.whatsappClean}`} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="font-mono text-emerald-400 hover:underline font-semibold block"
                  >
                    WhatsApp: {hotelContact.phone}
                  </a>
                  <span className="text-[10px] text-stone-500">{hotelContact.managerNameBn}</span>
                </div>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                <div>
                  <span className="text-stone-300 block">{hotelContact.addressBn}</span>
                  <a 
                    href={hotelContact.mapsUrl}
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="text-amber-400 hover:underline text-[10.5px] inline-flex items-center gap-1 mt-0.5"
                  >
                    <span>{lang === "bn" ? "গুগল ম্যাপ লিংক" : "Google Maps Pin"}</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </li>
            </ul>
          </div>

          {/* Column 4: Savar Landmarks */}
          <div>
            <h5 className="font-serif text-amber-400 text-xs uppercase tracking-wider mb-4 font-bold">
              {lang === "bn" ? "নিকটবর্তী স্থানসমূহ" : "Nearby Landmarks"}
            </h5>
            <ul className="space-y-2 text-xs text-stone-400">
              {savarAttractions.map((attr) => (
                <li key={attr.id} className="flex justify-between items-center gap-2 border-b border-stone-800/60 pb-1.5">
                  <span className="truncate">{lang === "bn" ? attr.nameBn.split("(")[0] : attr.nameEn}</span>
                  <span className="text-[10px] text-amber-400/90 font-mono shrink-0">
                    {lang === "bn" ? attr.distanceBn.split("(")[0] : attr.distanceEn}
                  </span>
                </li>
              ))}
            </ul>
          </div>

        </div>

        <div className="h-px bg-stone-800 max-w-7xl mx-auto my-8" />

        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-stone-500 font-mono">
          <p>
            &copy; 2026 Bandhan Guest House (CRP) — {hotelContact.nameBn}. All rights reserved.
          </p>
          <div className="flex gap-3">
            <span>{hotelContact.addressBn}</span>
            <span>•</span>
            <span>{hotelContact.managerBn}</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
