/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Room {
  id: string;
  nameBn: string;
  nameEn: string;
  taglineBn: string;
  taglineEn: string;
  descriptionBn: string;
  descriptionEn: string;
  pricePerNight: number;
  dayStayPrice: number;
  nightStayPrice: number;
  capacity: number;
  bedTypeBn: string;
  bedTypeEn: string;
  sizeSft: number;
  isSizeVerified: boolean;
  featured: boolean;
  amenitiesBn: string[];
  amenitiesEn: string[];
  imageUrl: string;
  galleryImages: string[];
  category: "deluxe" | "executive" | "standard";
  policy12hBn: string;
  policy12hEn: string;
}

export interface BookingInquiry {
  id: string;
  guestName: string;
  phone: string;
  email: string;
  checkInDate: string;
  checkInTime: string;
  checkOutDate: string;
  roomId: string;
  roomType: "ac" | "non_ac";
  stayType: "day_12h" | "night" | "full_stay";
  guestsCount: number;
  specialRequests: string;
  totalPrice: number;
  calculatedNights: number;
  referenceNumber: string;
  createdAt: string;
  status: "pending_confirmation" | "confirmed" | "cancelled";
}

export interface Amenity {
  id: string;
  nameBn: string;
  nameEn: string;
  iconName: string;
  descriptionBn: string;
  descriptionEn: string;
}

export interface SavarAttraction {
  id: string;
  nameBn: string;
  nameEn: string;
  distanceBn: string;
  distanceEn: string;
  descriptionBn: string;
  descriptionEn: string;
  imageUrl?: string;
}

export interface FAQItem {
  id: string;
  questionBn: string;
  questionEn: string;
  answerBn: string;
  answerEn: string;
  category: "service" | "policy" | "location";
}

export interface Review {
  id: string;
  authorBn: string;
  authorEn: string;
  rating: number;
  commentBn: string;
  commentEn: string;
  dateBn: string;
  dateEn: string;
  roleBn: string;
  roleEn: string;
}

export interface GalleryPhoto {
  id: string;
  titleBn: string;
  titleEn: string;
  category: "rooms" | "lounge" | "amenities";
  imageUrl: string;
  captionBn: string;
  captionEn: string;
}
