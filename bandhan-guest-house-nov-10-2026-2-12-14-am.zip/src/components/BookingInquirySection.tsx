/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Room, BookingInquiry } from "../types";
import { bandhanRooms, hotelContact } from "../data";
import { 
  Calendar, Users, Gift, Phone, Clock, User, Info, CheckCircle2, 
  Trash2, Receipt, DollarSign, FileText, ArrowRight, MessageSquare, 
  ExternalLink, Sparkles, AlertCircle, ShieldCheck
} from "lucide-react";

interface BookingInquirySectionProps {
  lang: "bn" | "en";
  selectedRoomId: string | null;
  onClearRoomSelection: () => void;
}

export default function BookingInquirySection({ 
  lang, 
  selectedRoomId, 
  onClearRoomSelection 
}: BookingInquirySectionProps) {
  // Form fields
  const [roomId, setRoomId] = useState<string>("ac-room");
  const [roomType, setRoomType] = useState<"ac" | "non_ac">("ac");
  const [stayType, setStayType] = useState<"day_12h" | "night" | "full_stay">("day_12h");
  const [guestName, setGuestName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [checkInDate, setCheckInDate] = useState("");
  const [checkInTime, setCheckInTime] = useState("12:00 PM");
  const [guestsCount, setGuestsCount] = useState(2);
  const [specialRequests, setSpecialRequests] = useState("");

  // Calculation and submission states
  const [totalPrice, setTotalPrice] = useState(2200);
  const [savedInquiries, setSavedInquiries] = useState<BookingInquiry[]>([]);
  const [latestVoucher, setLatestVoucher] = useState<BookingInquiry | null>(null);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Set default check-in date to today/tomorrow
  useEffect(() => {
    const today = new Date();
    const formatted = today.toISOString().split("T")[0];
    setCheckInDate(formatted);
  }, []);

  // Update when selectedRoomId changes from parent
  useEffect(() => {
    if (selectedRoomId) {
      setRoomId(selectedRoomId);
      setRoomType(selectedRoomId === "ac-room" ? "ac" : "non_ac");
      setValidationError(null);
    }
  }, [selectedRoomId]);

  // Sync roomType with roomId
  const handleRoomTypeChange = (type: "ac" | "non_ac") => {
    setRoomType(type);
    setRoomId(type === "ac" ? "ac-room" : "non-ac-room");
  };

  // Load inquiries from localStorage
  useEffect(() => {
    try {
      const stored = localStorage.getItem("bandhan_booking_inquiries");
      if (stored) {
        setSavedInquiries(JSON.parse(stored));
      }
    } catch (e) {
      console.error("Local storage error:", e);
    }
  }, []);

  // Price Calculation according to verified 12-hour rules
  useEffect(() => {
    if (stayType === "day_12h") {
      setTotalPrice(roomType === "ac" ? 2200 : 1500);
    } else if (stayType === "night") {
      setTotalPrice(roomType === "ac" ? 2400 : 1600);
    } else {
      // 24h Full Day calculation
      setTotalPrice(roomType === "ac" ? 2400 : 1600);
    }
  }, [roomId, roomType, stayType]);

  const activeRoom = bandhanRooms.find((r) => r.id === roomId) || bandhanRooms[0];

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);

    // Validation 1: Guest Name
    if (!guestName.trim() || guestName.trim().length < 2) {
      setValidationError(
        lang === "bn" 
          ? "অনুগ্রহ করে আপনার পূর্ণ নাম সঠিকভাবে লিখুন।" 
          : "Please provide your valid full name."
      );
      return;
    }

    // Validation 2: Mobile Number
    const cleanedPhone = phone.replace(/[\s-]/g, "");
    if (!cleanedPhone || cleanedPhone.length < 11) {
      setValidationError(
        lang === "bn" 
          ? "অনুগ্রহ করে সঠিক মোবাইল নম্বর প্রদান করুন (যেমন: 01XXXXXXXXX) যাতে আমরা যোগাযোগ করতে পারি।" 
          : "Please enter a valid 11-digit mobile number (e.g., 01XXXXXXXXX)."
      );
      return;
    }

    // Validation 3: Check-in Date
    if (!checkInDate) {
      setValidationError(
        lang === "bn" 
          ? "অনুগ্রহ করে চেক-ইন তারিখ নির্বাচন করুন।" 
          : "Please select your check-in date."
      );
      return;
    }

    // Validation 4: Check-in Time
    if (!checkInTime) {
      setValidationError(
        lang === "bn" 
          ? "অনুগ্রহ করে সম্ভাব্য চেক-ইন সময় নির্বাচন করুন।" 
          : "Please select estimated check-in time."
      );
      return;
    }

    // Validation 5: Capacity limit
    if (guestsCount > activeRoom.capacity) {
      setValidationError(
        lang === "bn"
          ? `নির্বাচিত রুমটিতে সর্বোচ্চ ${activeRoom.capacity} জন মেহমান অবস্থান করতে পারবেন।`
          : `Selected room accommodates a maximum of ${activeRoom.capacity} guests.`
      );
      return;
    }

    setIsSubmitting(true);

    // Generate unique reference
    const randomCode = Math.floor(1000 + Math.random() * 9000);
    const refCode = `BGH-SVR-${randomCode}`;

    const newInquiry: BookingInquiry = {
      id: `inq-${Date.now()}`,
      guestName: guestName.trim(),
      phone: cleanedPhone,
      email: email.trim() || "N/A",
      checkInDate,
      checkInTime,
      checkOutDate: checkInDate,
      roomId,
      roomType,
      stayType,
      guestsCount,
      specialRequests: specialRequests.trim() || (lang === "bn" ? "কোনো বিশেষ অনুরোধ নেই" : "None"),
      totalPrice,
      calculatedNights: 1,
      referenceNumber: refCode,
      createdAt: new Date().toLocaleString(),
      status: "pending_confirmation" // Notice: NOT pretending to be confirmed without host verification
    };

    const updated = [newInquiry, ...savedInquiries];
    setSavedInquiries(updated);
    setLatestVoucher(newInquiry);
    localStorage.setItem("bandhan_booking_inquiries", JSON.stringify(updated));

    // Generate WhatsApp URL with complete structured details
    const stayLabelBn = stayType === "day_12h" ? "ডে স্টে (১২ ঘণ্টা)" : stayType === "night" ? "নাইট স্টে (রাত্রীযাপন)" : "ফুল ডে স্টে";
    const stayLabelEn = stayType === "day_12h" ? "Day Stay (12 Hours)" : stayType === "night" ? "Night Stay" : "Full Day Stay";
    const roomLabelBn = roomType === "ac" ? "এসি রুম (AC Room)" : "নন-এসি রুম (Non-AC Room)";
    const roomLabelEn = roomType === "ac" ? "AC Room" : "Non-AC Room";

    const whatsappMessage = lang === "bn"
      ? `আসসালামু আলাইকুম শুভ ভাই, আমি বন্ধন গেস্ট হাউস (সি.আর.পি)-এ একটি রুম বুকিং আবেদন করেছি।\nঠিকানা: ${hotelContact.addressBn}\n\n📋 বুকিং বিবরণ:\n• রেফারেন্স: ${refCode}\n• অতিথির নাম: ${newInquiry.guestName}\n• মোবাইল: ${newInquiry.phone}\n• রুমের ধরন: ${roomLabelBn}\n• স্টে প্যাকেজ: ${stayLabelBn}\n• চেক-ইন তারিখ: ${checkInDate}\n• চেক-ইন সময়: ${checkInTime}\n• অতিথি সংখ্যা: ${guestsCount} জন\n• আনুমানিক ভাড়া: ৳${totalPrice}\n• বিশেষ অনুরোধ: ${newInquiry.specialRequests}\n\nঅনুগ্রহ করে আমার বুকিংটি কনফার্ম করুন। ধন্যবাদ!`
      : `Hello Shuvo Bhai (Manager), Bandhan Guest House (CRP),\nI have submitted a room booking inquiry.\nAddress: ${hotelContact.addressEn}\n\n📋 Booking Details:\n• Ref: ${refCode}\n• Guest Name: ${newInquiry.guestName}\n• Mobile: ${newInquiry.phone}\n• Room Type: ${roomLabelEn}\n• Stay Package: ${stayLabelEn}\n• Check-in Date: ${checkInDate}\n• Check-in Time: ${checkInTime}\n• Guests: ${guestsCount} person(s)\n• Estimated Tariff: BDT ${totalPrice}\n• Special Requests: ${newInquiry.specialRequests}\n\nPlease confirm my reservation. Thank you!`;

    const whatsappUrl = `https://wa.me/${hotelContact.whatsappClean}?text=${encodeURIComponent(whatsappMessage)}`;

    // Open WhatsApp in a new tab
    try {
      window.open(whatsappUrl, "_blank");
    } catch (err) {
      console.warn("Could not automatically open WhatsApp popup", err);
    }

    setIsSubmitting(false);
    onClearRoomSelection();
  };

  const deleteInquiry = (id: string) => {
    const updated = savedInquiries.filter((inq) => inq.id !== id);
    setSavedInquiries(updated);
    localStorage.setItem("bandhan_booking_inquiries", JSON.stringify(updated));
    if (latestVoucher && latestVoucher.id === id) {
      setLatestVoucher(null);
    }
  };

  const timeOptions = [
    "08:00 AM (সকাল ৮:০০)",
    "10:00 AM (সকাল ১০:০০)",
    "12:00 PM (দুপুর ১২:০০)",
    "02:00 PM (দুপুর ২:০০)",
    "04:00 PM (বিকাল ৪:০০)",
    "06:00 PM (সন্ধ্যা ৬:০০)",
    "08:00 PM (রাত ৮:০০)",
    "10:00 PM (রাত ১০:০০)",
    "যেকোনো সময় (Any Time - 24/7)"
  ];

  return (
    <div className="space-y-10 scroll-mt-20" id="booking-inquiry-section">
      
      {/* Section Header */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-800 bg-[#FAF1E3] px-3.5 py-1 rounded-full uppercase tracking-wider">
          <Calendar className="w-3.5 h-3.5" />
          <span>{lang === "bn" ? "সহজ রুম বুকিং সিস্টেম" : "Room Booking System"}</span>
        </div>
        
        <h3 className="font-serif text-2xl sm:text-3xl md:text-4xl font-bold text-stone-900 leading-tight">
          {lang === "bn" ? "বন্ধন গেস্ট হাউসে বুকিং আবেদন করুন" : "Book Your Stay at Bandhan Guest House"}
        </h3>
        
        <p className="text-stone-600 text-xs sm:text-sm md:text-base">
          {lang === "bn" 
            ? "কোনো অগ্রিম পেমেন্ট ছাড়া সরাসরি ফর্ম পূরণ করুন। এরপর আমরা হোয়াটসঅ্যাপে নিশ্চিত করব।" 
            : "No advance payment needed. Fill out the details below and confirm instantly via WhatsApp."}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Booking Form Column */}
        <div className="lg:col-span-7 bg-white border border-[#E7DDCB] shadow-sm rounded-2xl sm:rounded-3xl p-6 sm:p-8 space-y-6">
          
          <div className="flex items-center gap-3 border-b border-[#E7DDCB] pb-4">
            <div className="w-10 h-10 rounded-xl bg-[#FAF1E3] text-[#B45309] flex items-center justify-center shrink-0">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-serif text-lg sm:text-xl font-bold text-stone-900">
                {lang === "bn" ? "বুকিং তথ্য পূরণ করুন" : "Fill Booking Details"}
              </h4>
              <p className="text-stone-500 text-xs">
                {lang === "bn" ? "হোয়াটসঅ্যাপ ও ফোনে তাৎক্ষণিক যোগাযোগ হবে" : "Instant communication via WhatsApp & phone"}
              </p>
            </div>
          </div>

          {/* 12-Hour Booking Policy Highlight Card */}
          <div className="bg-[#FAF1E3] border-l-4 border-[#B45309] p-4 rounded-xl space-y-1.5 text-xs">
            <div className="flex items-center justify-between text-stone-900 font-bold">
              <span className="flex items-center gap-1.5 text-amber-900">
                <Clock className="w-4 h-4 text-[#B45309]" />
                {lang === "bn" ? "১২ ঘণ্টার বুকিং নীতিমালা" : "12-Hour Booking Policy"}
              </span>
              <span className="text-[10px] bg-amber-800 text-white px-2 py-0.5 rounded-full font-mono uppercase">
                {lang === "bn" ? "সাশ্রয়ী প্যাকেজ" : "Verified Rates"}
              </span>
            </div>
            <p className="text-stone-800 font-medium leading-relaxed">
              "{hotelContact.policy12hBn}"
            </p>
            <div className="grid grid-cols-2 gap-2 pt-2 text-[11px] font-mono font-semibold text-stone-900">
              <div className="bg-white/90 p-2 rounded-lg border border-amber-200">
                <span className="block text-[9.5px] text-stone-500 font-sans">☀️ {lang === "bn" ? "ডে স্টে (১২ ঘণ্টা):" : "Day Stay (12h):"}</span>
                <span>নন-এসি ৳১,৫০০ | এসি ৳২,২০০</span>
              </div>
              <div className="bg-white/90 p-2 rounded-lg border border-amber-200">
                <span className="block text-[9.5px] text-stone-500 font-sans">🌙 {lang === "bn" ? "নাইট স্টে (রাত্রীযাপন):" : "Night Stay:"}</span>
                <span>নন-এসি ৳১,৬০০ | এসি ৳২,৪০০</span>
              </div>
            </div>
          </div>

          {/* Error Banner */}
          {validationError && (
            <div className="bg-red-50 border border-red-200 text-red-800 text-xs sm:text-sm p-4 rounded-xl flex items-start gap-2.5 animate-shake">
              <Info className="w-4 h-4 shrink-0 mt-0.5 text-red-600" />
              <span>{validationError}</span>
            </div>
          )}

          <form onSubmit={handleBookingSubmit} className="space-y-5">
            
            {/* Guest Name & Mobile Number */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-stone-800">
                  {lang === "bn" ? "অতিথির নাম *" : "Guest Full Name *"}
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={guestName}
                    onChange={(e) => setGuestName(e.target.value)}
                    placeholder={lang === "bn" ? "আপনার পূর্ণ নাম লিখুন" : "Enter your full name"}
                    className="w-full pl-10 pr-4 py-2.5 bg-[#FCFBF8] border border-stone-300 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#B45309] focus:border-transparent transition"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-stone-800">
                  {lang === "bn" ? "মোবাইল নম্বর *" : "Mobile Number *"}
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder={lang === "bn" ? "০১৯XXXXXXXX বা ০১৩XXXXXXXX" : "019XXXXXXXX or 013XXXXXXXX"}
                    className="w-full pl-10 pr-4 py-2.5 bg-[#FCFBF8] border border-stone-300 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#B45309] focus:border-transparent font-mono transition"
                  />
                </div>
              </div>
            </div>

            {/* Room Type Selector (AC / Non-AC) */}
            <div className="space-y-2">
              <label className="block text-xs font-semibold text-stone-800">
                {lang === "bn" ? "রুমের ধরন (Room Type) *" : "Room Type *"}
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => handleRoomTypeChange("ac")}
                  className={`p-3 rounded-xl border text-left transition cursor-pointer ${
                    roomType === "ac"
                      ? "border-[#B45309] bg-amber-50/80 ring-2 ring-amber-300 text-stone-900"
                      : "border-stone-200 bg-[#FCFBF8] hover:bg-stone-50 text-stone-700"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs sm:text-sm">
                      {lang === "bn" ? "এসি রুম (AC Room)" : "AC Room"}
                    </span>
                    <span className="w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center border-[#B45309]">
                      {roomType === "ac" && <span className="w-2 h-2 rounded-full bg-[#B45309]" />}
                    </span>
                  </div>
                  <span className="text-[11px] text-stone-500 block mt-1">
                    {lang === "bn" ? "স্প্লিট এসি, গিজার, এলইডি টিভি" : "Split AC, Geyser, Smart TV"}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => handleRoomTypeChange("non_ac")}
                  className={`p-3 rounded-xl border text-left transition cursor-pointer ${
                    roomType === "non_ac"
                      ? "border-[#B45309] bg-amber-50/80 ring-2 ring-amber-300 text-stone-900"
                      : "border-stone-200 bg-[#FCFBF8] hover:bg-stone-50 text-stone-700"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs sm:text-sm">
                      {lang === "bn" ? "নন-এসি রুম (Non-AC)" : "Non-AC Room"}
                    </span>
                    <span className="w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center border-[#B45309]">
                      {roomType === "non_ac" && <span className="w-2 h-2 rounded-full bg-[#B45309]" />}
                    </span>
                  </div>
                  <span className="text-[11px] text-stone-500 block mt-1">
                    {lang === "bn" ? "হাই-স্পিড ফ্যান, ওয়াই-ফাই, টিভি" : "High-speed fan, Wi-Fi, TV"}
                  </span>
                </button>
              </div>
            </div>

            {/* Stay Package Type (12h Day Stay vs Night Stay) */}
            <div className="space-y-2">
              <label className="block text-xs font-semibold text-stone-800">
                {lang === "bn" ? "স্টে প্যাকেজ (Stay Duration) *" : "Stay Duration *"}
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setStayType("day_12h")}
                  className={`p-3 rounded-xl border text-left transition cursor-pointer ${
                    stayType === "day_12h"
                      ? "border-[#B45309] bg-amber-50/80 ring-2 ring-amber-300 text-stone-900"
                      : "border-stone-200 bg-[#FCFBF8] hover:bg-stone-50 text-stone-700"
                  }`}
                >
                  <span className="font-bold text-xs sm:text-sm block">
                    ☀️ {lang === "bn" ? "ডে স্টে (১২ ঘণ্টা)" : "Day Stay (12 Hours)"}
                  </span>
                  <span className="text-xs font-mono font-bold text-[#B45309] block mt-0.5">
                    ৳{roomType === "ac" ? "২,২০০" : "১,৫০০"}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setStayType("night")}
                  className={`p-3 rounded-xl border text-left transition cursor-pointer ${
                    stayType === "night"
                      ? "border-[#B45309] bg-amber-50/80 ring-2 ring-amber-300 text-stone-900"
                      : "border-stone-200 bg-[#FCFBF8] hover:bg-stone-50 text-stone-700"
                  }`}
                >
                  <span className="font-bold text-xs sm:text-sm block">
                    🌙 {lang === "bn" ? "নাইট স্টে (রাত্রীযাপন)" : "Night Stay"}
                  </span>
                  <span className="text-xs font-mono font-bold text-[#B45309] block mt-0.5">
                    ৳{roomType === "ac" ? "২,৪০০" : "১,৬০০"}
                  </span>
                </button>
              </div>
            </div>

            {/* Check-in Date & Check-in Time */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-stone-800">
                  {lang === "bn" ? "চেক-ইন তারিখ *" : "Check-in Date *"}
                </label>
                <div className="relative">
                  <Calendar className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="date"
                    required
                    value={checkInDate}
                    onChange={(e) => setCheckInDate(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 bg-[#FCFBF8] border border-stone-300 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#B45309] focus:border-transparent font-mono transition"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-stone-800">
                  {lang === "bn" ? "চেক-ইন সময় *" : "Check-in Time *"}
                </label>
                <div className="relative">
                  <Clock className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <select
                    value={checkInTime}
                    onChange={(e) => setCheckInTime(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 bg-[#FCFBF8] border border-stone-300 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#B45309] focus:border-transparent transition"
                  >
                    {timeOptions.map((opt, i) => (
                      <option key={i} value={opt}>{opt}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Number of Guests & Optional Email */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-stone-800">
                  {lang === "bn" ? "অতিথি সংখ্যা *" : "Number of Guests *"}
                </label>
                <div className="relative">
                  <Users className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <select
                    value={guestsCount}
                    onChange={(e) => setGuestsCount(Number(e.target.value))}
                    className="w-full pl-10 pr-4 py-2.5 bg-[#FCFBF8] border border-stone-300 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#B45309] focus:border-transparent transition"
                  >
                    <option value={1}>{lang === "bn" ? "১ জন মেহমান" : "1 Guest"}</option>
                    <option value={2}>{lang === "bn" ? "২ জন মেহমান (সর্বোচ্চ)" : "2 Guests (Standard)"}</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-stone-800">
                  {lang === "bn" ? "ইমেইল (ঐচ্ছিক)" : "Email (Optional)"}
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full px-4 py-2.5 bg-[#FCFBF8] border border-stone-300 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#B45309] focus:border-transparent transition"
                />
              </div>
            </div>

            {/* Special Requests */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-stone-800">
                {lang === "bn" ? "বিশেষ কোনো অনুরোধ বা তথ্য (ঐচ্ছিক)" : "Special Requests (Optional)"}
              </label>
              <textarea
                rows={2}
                value={specialRequests}
                onChange={(e) => setSpecialRequests(e.target.value)}
                placeholder={lang === "bn" ? "যেমন: অতিরিক্ত বালিশ, নির্দিষ্ট চেক-ইন সময় ইত্যাদি..." : "e.g., extra pillows, specific arrival details..."}
                className="w-full p-3 bg-[#FCFBF8] border border-stone-300 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#B45309] focus:border-transparent transition"
              />
            </div>

            {/* Transparent Cost Calculation Bar */}
            <div className="bg-[#FAF8F5] border border-[#E7DDCB] p-4 rounded-xl flex items-center justify-between">
              <div>
                <span className="text-xs text-stone-500 block">
                  {lang === "bn" ? "প্রদেয় সর্বমোট ভাড়া (কাউন্টারে পরিশোধযোগ্য):" : "Total Payable Amount (Pay at Counter):"}
                </span>
                <span className="text-[11px] text-amber-800 font-medium">
                  {roomType === "ac" ? "এসি রুম" : "নন-এসি রুম"} • {stayType === "day_12h" ? "ডে স্টে (১২ ঘণ্টা)" : "নাইট স্টে"}
                </span>
              </div>
              <div className="text-right">
                <span className="text-2xl font-bold font-mono text-stone-900 block">
                  ৳{totalPrice.toLocaleString()}
                </span>
                <span className="text-[10px] text-emerald-700 font-semibold">
                  {lang === "bn" ? "কোনো অগ্রিম চার্জ নেই" : "No advance payment"}
                </span>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              id="submit-booking-inquiry-btn"
              className="w-full bg-[#B45309] hover:bg-[#92400E] text-white py-3.5 px-6 rounded-xl font-bold text-sm sm:text-base flex items-center justify-center gap-2 cursor-pointer shadow-md transition-all active:scale-[0.99]"
            >
              <MessageSquare className="w-5 h-5 fill-white" />
              <span>
                {lang === "bn" ? "বুকিং আবেদন জমা দিন ও হোয়াটসঅ্যাপে পাঠান" : "Submit Booking & Open WhatsApp"}
              </span>
              <ArrowRight className="w-4 h-4 ml-1" />
            </button>

            <div className="flex items-center justify-center gap-2 text-[11px] text-stone-500 pt-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>{lang === "bn" ? `সরাসরি ম্যানেজার শুভ (${hotelContact.phone})-এর সাথে হোয়াটসঅ্যাপ কানেক্ট হবে।` : `Directly opens WhatsApp to Manager Shuvo (${hotelContact.phone}).`}</span>
            </div>

          </form>

        </div>

        {/* Booking Summary & Confirmation Column */}
        <div className="lg:col-span-5 space-y-6">
          
          {latestVoucher ? (
            <div className="bg-stone-900 text-white rounded-2xl sm:rounded-3xl p-6 sm:p-7 shadow-xl border border-stone-800 relative overflow-hidden animate-fade-in">
              <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

              <div className="flex items-center justify-between pb-4 border-b border-stone-800">
                <div className="flex items-center gap-2.5">
                  <img
                    src={hotelContact.logoUrl}
                    alt="Bandhan Guest House Logo"
                    className="w-10 h-10 rounded-full object-cover border-2 border-amber-400"
                  />
                  <div>
                    <h5 className="font-serif font-bold text-sm">
                      {lang === "bn" ? hotelContact.nameBn : hotelContact.nameEn}
                    </h5>
                    <span className="text-[10px] text-amber-400 font-mono">
                      {latestVoucher.referenceNumber}
                    </span>
                  </div>
                </div>

                {/* Important notice: explicitly pending confirmation until host accepts */}
                <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-400/40 px-2.5 py-1 rounded-full font-semibold">
                  {lang === "bn" ? "আবেদন জমা হয়েছে" : "Inquiry Submitted"}
                </span>
              </div>

              {/* Status explanation */}
              <div className="bg-stone-800/80 border border-amber-500/30 p-3 rounded-xl my-4 text-xs space-y-1">
                <div className="flex items-center gap-1.5 text-amber-400 font-semibold">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{lang === "bn" ? "গেস্ট হাউসের নিশ্চিতকরণ সাপেক্ষ" : "Pending Final Confirmation"}</span>
                </div>
                <p className="text-stone-300 text-[11px] leading-relaxed">
                  {lang === "bn"
                    ? `আপনার বুকিং আবেদনটি সিস্টেমে নথিভুক্ত হয়েছে। আমাদের ম্যানেজার শুভ ভাই (${hotelContact.phone}) হোয়াটসঅ্যাপে তথ্য যাচাই করে বুকিং নিশ্চিত করবেন।`
                    : `Your inquiry is logged. Final confirmation will be completed by Manager Shuvo (${hotelContact.phone}) via WhatsApp.`}
                </p>
              </div>

              {/* Summary Specs */}
              <div className="space-y-2.5 text-xs border-b border-stone-800 pb-4">
                <div className="flex justify-between">
                  <span className="text-stone-400">{lang === "bn" ? "অতিথির নাম:" : "Guest Name:"}</span>
                  <span className="font-semibold text-white">{latestVoucher.guestName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-400">{lang === "bn" ? "মোবাইল নম্বর:" : "Mobile Number:"}</span>
                  <span className="font-mono font-semibold text-white">{latestVoucher.phone}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-400">{lang === "bn" ? "রুমের ধরন:" : "Room Type:"}</span>
                  <span className="font-semibold text-amber-300">
                    {latestVoucher.roomType === "ac" ? "এসি রুম (AC Room)" : "নন-এসি রুম (Non-AC Room)"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-400">{lang === "bn" ? "প্যাকেজ:" : "Package:"}</span>
                  <span className="font-semibold text-white">
                    {latestVoucher.stayType === "day_12h" ? "ডে স্টে (১২ ঘণ্টা)" : "নাইট স্টে (রাত্রীযাপন)"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-400">{lang === "bn" ? "চেক-ইন তারিখ ও সময়:" : "Check-in Date & Time:"}</span>
                  <span className="font-mono text-white">{latestVoucher.checkInDate} ({latestVoucher.checkInTime})</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-400">{lang === "bn" ? "অতিথি সংখ্যা:" : "Guests:"}</span>
                  <span className="font-semibold text-white">{latestVoucher.guestsCount} {lang === "bn" ? "জন" : "person(s)"}</span>
                </div>
                {latestVoucher.specialRequests && latestVoucher.specialRequests !== "None" && (
                  <div className="flex justify-between">
                    <span className="text-stone-400">{lang === "bn" ? "অনুরোধ:" : "Requests:"}</span>
                    <span className="font-light text-stone-300 truncate max-w-[180px]">{latestVoucher.specialRequests}</span>
                  </div>
                )}
              </div>

              {/* Total Payable */}
              <div className="pt-4 flex justify-between items-baseline">
                <div>
                  <span className="text-xs text-stone-400 block">{lang === "bn" ? "কাউন্টারে প্রদেয় ভাড়া:" : "Payable Tariff at Desk:"}</span>
                  <span className="text-[10px] text-stone-500">{lang === "bn" ? "(১২ ঘণ্টার নির্ধারিত ভাড়া)" : "(Fixed 12h Tariff)"}</span>
                </div>
                <span className="text-2xl font-bold font-mono text-amber-400">
                  ৳{latestVoucher.totalPrice.toLocaleString()}
                </span>
              </div>

              {/* WhatsApp Action Button */}
              <div className="pt-5 space-y-2">
                <a
                  href={`https://wa.me/${hotelContact.whatsappClean}?text=${encodeURIComponent(
                    lang === "bn"
                      ? `আসসালামু আলাইকুম শুভ ভাই, আমি বন্ধন গেস্ট হাউস (সি.আর.পি)-এ একটি রুম বুকিং আবেদন করেছি।\nঠিকানা: ${hotelContact.addressBn}\n\n📋 বুকিং বিবরণ:\n• রেফারেন্স: ${latestVoucher.referenceNumber}\n• অতিথির নাম: ${latestVoucher.guestName}\n• মোবাইল: ${latestVoucher.phone}\n• রুমের ধরন: ${latestVoucher.roomType === "ac" ? "এসি রুম" : "নন-এসি রুম"}\n• স্টে প্যাকেজ: ${latestVoucher.stayType === "day_12h" ? "ডে স্টে (১২ ঘণ্টা)" : "নাইট স্টে"}\n• চেক-ইন তারিখ: ${latestVoucher.checkInDate}\n• চেক-ইন সময়: ${latestVoucher.checkInTime}\n• অতিথি সংখ্যা: ${latestVoucher.guestsCount} জন\n• মোট ভাড়া: ৳${latestVoucher.totalPrice}\n\nঅনুগ্রহ করে আমার বুকিংটি কনফার্ম করুন। ধন্যবাদ!`
                      : `Hello Shuvo Bhai (Manager), Bandhan Guest House (CRP),\nI have submitted a room booking inquiry.\nAddress: ${hotelContact.addressEn}\nRef: ${latestVoucher.referenceNumber}\nGuest: ${latestVoucher.guestName}\nPhone: ${latestVoucher.phone}\nRoom: ${latestVoucher.roomType === "ac" ? "AC Room" : "Non-AC Room"}\nCheck-in: ${latestVoucher.checkInDate} at ${latestVoucher.checkInTime}\nTariff: BDT ${latestVoucher.totalPrice}\n\nPlease confirm my reservation. Thank you!`
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 px-4 rounded-xl flex items-center justify-center gap-2 text-xs sm:text-sm transition-colors shadow-sm"
                >
                  <MessageSquare className="w-4 h-4 fill-white" />
                  <span>{lang === "bn" ? `হোয়াটসঅ্যাপে পাঠান (${hotelContact.phone})` : `Send to WhatsApp (${hotelContact.phone})`}</span>
                </a>

                <button
                  onClick={() => setLatestVoucher(null)}
                  className="w-full text-stone-400 hover:text-white text-center text-xs py-1.5 transition underline cursor-pointer"
                >
                  {lang === "bn" ? "আরেকটি বুকিং করতে রসিদ বন্ধ করুন" : "Close summary to book another"}
                </button>
              </div>

            </div>
          ) : (
            <div className="bg-[#FAF8F5] border border-[#E7DDCB] p-6 rounded-2xl sm:rounded-3xl text-center space-y-3">
              <div className="w-12 h-12 bg-[#FAF1E3] rounded-2xl flex items-center justify-center text-[#B45309] mx-auto">
                <Gift className="w-6 h-6" />
              </div>
              <h5 className="font-serif text-base font-bold text-stone-900">
                {lang === "bn" ? "নিরাপদ ও ঝুঁকিহীন রুম বুকিং" : "Risk-Free Direct Reservation"}
              </h5>
              <p className="text-stone-600 text-xs leading-relaxed max-w-sm mx-auto">
                {lang === "bn"
                  ? "বন্ধন গেস্ট হাউসে কোনো অনলাইন কার্ড বা অগ্রিম পেমেন্টের প্রয়োজন নেই। সরাসরি বুকিং আবেদন করে রিসেপশনে এসে চেক-ইনের সময় অর্থ পরিশোধ করুন।"
                  : "No advance bank deposit or credit card required. Submit your reservation request and pay at the front desk upon arrival."}
              </p>
              <div className="pt-2 flex flex-col items-center gap-1 text-xs font-mono text-stone-700">
                <span>{lang === "bn" ? "হটলাইন:" : "Helpline:"} <strong className="text-stone-900">{hotelContact.phone}</strong></span>
                <span>{lang === "bn" ? "হোয়াটসঅ্যাপ:" : "WhatsApp:"} <strong className="text-emerald-700">{hotelContact.whatsapp}</strong></span>
              </div>
            </div>
          )}

          {/* Past Inquiries List */}
          <div className="bg-white border border-[#E7DDCB] rounded-2xl sm:rounded-3xl p-5 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h5 className="font-serif text-sm font-bold text-stone-900 flex items-center gap-2">
                <FileText className="w-4 h-4 text-amber-700" />
                <span>{lang === "bn" ? "আপনার বুকিং আবেদনের রেকর্ড" : "Recent Booking Inquiries"}</span>
              </h5>
              <span className="text-[10px] bg-stone-100 text-stone-600 px-2.5 py-0.5 rounded-full font-mono font-semibold">
                {savedInquiries.length}
              </span>
            </div>

            {savedInquiries.length === 0 ? (
              <p className="text-stone-400 text-xs text-center py-4">
                {lang === "bn" ? "এই ডিভাইসে এখনও কোনো বুকিং করা হয়নি।" : "No recent inquiries from this device."}
              </p>
            ) : (
              <div className="space-y-3 max-h-56 overflow-y-auto pr-1">
                {savedInquiries.map((inq) => (
                  <div key={inq.id} className="border border-stone-200/80 rounded-xl p-3 bg-[#FCFBF8] flex justify-between items-center gap-3">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-[10.5px] font-bold text-[#B45309]">
                          {inq.referenceNumber}
                        </span>
                        <span className="text-[9px] text-stone-400">{inq.createdAt}</span>
                      </div>
                      <p className="text-xs font-semibold text-stone-900 truncate mt-0.5">
                        {inq.roomType === "ac" ? "এসি রুম" : "নন-এসি রুম"} ({inq.stayType === "day_12h" ? "ডে স্টে" : "নাইট"})
                      </p>
                      <div className="text-[10.5px] text-stone-500 font-mono mt-0.5 flex gap-2">
                        <span>{inq.checkInDate}</span>
                        <span>•</span>
                        <span className="font-bold text-stone-800">৳{inq.totalPrice}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() => setLatestVoucher(inq)}
                        className="bg-[#FAF1E3] hover:bg-amber-100 text-[#854D0E] text-[10px] px-2.5 py-1 rounded-md font-semibold cursor-pointer transition"
                      >
                        {lang === "bn" ? "রসিদ" : "View"}
                      </button>
                      <button
                        onClick={() => deleteInquiry(inq.id)}
                        className="text-stone-400 hover:text-red-600 p-1 rounded-md transition cursor-pointer"
                        aria-label="Delete inquiry"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>

      </div>

    </div>
  );
}
