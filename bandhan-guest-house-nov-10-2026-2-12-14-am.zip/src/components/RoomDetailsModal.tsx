/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Room } from "../types";
import { 
  X, Check, ShieldCheck, Bed, Users, Maximize, Clock, 
  ArrowRight, Phone, MessageSquare, AlertCircle, Sparkles
} from "lucide-react";
import { hotelContact } from "../data";

interface RoomDetailsModalProps {
  room: Room | null;
  lang: "bn" | "en";
  onClose: () => void;
  onBookNow: (roomId: string) => void;
}

export default function RoomDetailsModal({
  room,
  lang,
  onClose,
  onBookNow
}: RoomDetailsModalProps) {
  if (!room) return null;

  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const images = room.galleryImages.length > 0 ? room.galleryImages : [room.imageUrl];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-950/80 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div 
        className="bg-white border border-[#E7DDCB] rounded-2xl sm:rounded-3xl max-w-3xl w-full max-h-[92vh] overflow-y-auto shadow-2xl flex flex-col my-auto"
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-room-title"
      >
        {/* Modal Header */}
        <div className="sticky top-0 z-20 bg-white/95 backdrop-blur-xs border-b border-[#E7DDCB] px-5 sm:px-6 py-4 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300">
                {room.isSizeVerified ? (lang === "bn" ? "যাচাইকৃত তথ্য" : "Verified Room") : (lang === "bn" ? "অফিসিয়াল রুম" : "Official Room")}
              </span>
              <span className="text-[10px] text-stone-500 font-mono">
                ID: {room.id}
              </span>
            </div>
            <h3 id="modal-room-title" className="font-serif text-lg sm:text-2xl font-bold text-stone-900 mt-1">
              {lang === "bn" ? room.nameBn : room.nameEn}
            </h3>
          </div>

          <button
            onClick={onClose}
            id="close-room-details-modal"
            className="p-2 text-stone-400 hover:text-stone-900 hover:bg-stone-100 rounded-full transition-colors cursor-pointer"
            aria-label="Close Room Details"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 space-y-6 flex-1">
          
          {/* Main Photo Gallery Carousel / Lightbox in Modal */}
          <div className="space-y-3">
            <div className="relative aspect-[16/10] sm:aspect-[16/9] w-full rounded-2xl overflow-hidden bg-stone-900 border border-stone-200 shadow-inner">
              <img
                src={images[activeImageIndex]}
                alt={lang === "bn" ? room.nameBn : room.nameEn}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-all duration-300"
              />
              <div className="absolute bottom-3 right-3 bg-stone-950/80 backdrop-blur-xs text-white text-[11px] font-mono px-2.5 py-1 rounded-md border border-stone-700">
                {activeImageIndex + 1} / {images.length} {lang === "bn" ? "ছবি" : "Photos"}
              </div>
            </div>

            {/* Thumbnails list */}
            {images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto pb-1">
                {images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIndex(idx)}
                    className={`relative w-20 h-14 rounded-lg overflow-hidden border-2 shrink-0 transition-all cursor-pointer ${
                      activeImageIndex === idx ? "border-[#B45309] ring-2 ring-amber-300" : "border-stone-200 opacity-70 hover:opacity-100"
                    }`}
                  >
                    <img src={img} alt={`Thumbnail ${idx + 1}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Key Quick Specs Badge row */}
          <div className="grid grid-cols-3 gap-2 p-3 bg-[#FAF8F5] border border-[#E7DDCB] rounded-xl text-center text-xs">
            <div className="flex flex-col items-center justify-center p-1">
              <Bed className="w-4 h-4 text-amber-700 mb-1" />
              <span className="text-stone-500 text-[10px]">{lang === "bn" ? "বেড টাইপ" : "Bed Type"}</span>
              <span className="font-semibold text-stone-900 truncate max-w-[130px]">{lang === "bn" ? room.bedTypeBn : room.bedTypeEn}</span>
            </div>
            <div className="flex flex-col items-center justify-center p-1 border-x border-[#E7DDCB]">
              <Users className="w-4 h-4 text-amber-700 mb-1" />
              <span className="text-stone-500 text-[10px]">{lang === "bn" ? "ধারণক্ষমতা" : "Capacity"}</span>
              <span className="font-semibold text-stone-900">{room.capacity} {lang === "bn" ? "জন মেহমান" : "Guests"}</span>
            </div>
            <div className="flex flex-col items-center justify-center p-1">
              <Maximize className="w-4 h-4 text-amber-700 mb-1" />
              <span className="text-stone-500 text-[10px]">{lang === "bn" ? "রুমের সাইজ" : "Room Area"}</span>
              <span className="font-semibold text-stone-900">{room.sizeSft} Sq.Ft ({lang === "bn" ? "যাচাইকৃত" : "Verified"})</span>
            </div>
          </div>

          {/* 12-Hour Booking Policy Highlight Card */}
          <div className="bg-[#FAF1E3] border-l-4 border-[#B45309] p-4 rounded-xl space-y-2">
            <div className="flex items-center gap-2 text-stone-900 font-bold text-xs sm:text-sm">
              <Clock className="w-4 h-4 text-[#B45309]" />
              <span>{lang === "bn" ? "১২ ঘণ্টার বুকিং নীতিমালা" : "12-Hour Booking Policy"}</span>
            </div>
            <p className="text-stone-800 text-xs sm:text-sm leading-relaxed font-medium">
              "{lang === "bn" ? room.policy12hBn : room.policy12hEn}"
            </p>
          </div>

          {/* Pricing Details */}
          <div className="border border-stone-200 rounded-xl p-4 bg-white space-y-3">
            <h4 className="font-serif text-sm font-bold text-stone-900">
              {lang === "bn" ? "দিন ও রাতের নির্ধারিত ভাড়া তালিকা" : "Verified Day & Night Tariff Rates"}
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-amber-50/70 border border-amber-200/80 rounded-xl">
                <span className="text-[10.5px] text-amber-800 font-semibold block">☀️ {lang === "bn" ? "ডে স্টে (১২ ঘণ্টা)" : "Day Stay (12 Hours)"}</span>
                <span className="text-xl font-bold font-mono text-stone-900 block mt-1">৳{room.dayStayPrice.toLocaleString()}</span>
                <span className="text-[10px] text-stone-500 block mt-0.5">{lang === "bn" ? "সকাল থেকে রাত শিফট" : "Morning to Evening shift"}</span>
              </div>
              <div className="p-3 bg-stone-100 border border-stone-200 rounded-xl">
                <span className="text-[10.5px] text-stone-700 font-semibold block">🌙 {lang === "bn" ? "নাইট স্টে (রাত্রীযাপন)" : "Night Stay"}</span>
                <span className="text-xl font-bold font-mono text-stone-900 block mt-1">৳{room.nightStayPrice.toLocaleString()}</span>
                <span className="text-[10px] text-stone-500 block mt-0.5">{lang === "bn" ? "রাত থেকে সকাল শিফট" : "Overnight rest shift"}</span>
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <h4 className="font-serif text-sm font-bold text-stone-900">
              {lang === "bn" ? "কক্ষের বিবরণ" : "Room Overview"}
            </h4>
            <p className="text-stone-600 text-xs sm:text-sm leading-relaxed">
              {lang === "bn" ? room.descriptionBn : room.descriptionEn}
            </p>
          </div>

          {/* Verified Facilities Checklist */}
          <div className="space-y-3">
            <h4 className="font-serif text-sm font-bold text-stone-900 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>{lang === "bn" ? "অন্তর্ভুক্ত সুযোগ-সুবিধাসমূহ (যাচাইকৃত)" : "Included Verified Facilities"}</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              {(lang === "bn" ? room.amenitiesBn : room.amenitiesEn).map((facility, idx) => (
                <div key={idx} className="flex items-center gap-2 p-2 rounded-lg bg-[#FCFBF8] border border-stone-200/70">
                  <span className="w-4 h-4 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                    <Check className="w-3 h-3" />
                  </span>
                  <span className="text-stone-700">{facility}</span>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Modal Footer CTA */}
        <div className="sticky bottom-0 z-20 bg-stone-50 border-t border-[#E7DDCB] px-5 sm:px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <a
              href={`tel:${hotelContact.phone}`}
              className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 text-xs font-semibold text-stone-800 bg-white border border-stone-300 hover:bg-stone-100 px-3 py-2.5 rounded-xl transition"
            >
              <Phone className="w-3.5 h-3.5 text-amber-700" />
              <span>{hotelContact.phone}</span>
            </a>
            <a
              href={`https://wa.me/${hotelContact.whatsappClean}?text=${encodeURIComponent(
                lang === "bn"
                  ? `আসসালামু আলাইকুম, আমি বন্ধন গেস্ট হাউসের ${room.nameBn} সম্পর্কে জানতে এবং বুকিং করতে চাই।`
                  : `Hello, I would like to inquire about booking the ${room.nameEn} at Bandhan Guest House.`
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-300 hover:bg-emerald-100 px-3 py-2.5 rounded-xl transition"
            >
              <MessageSquare className="w-3.5 h-3.5 fill-emerald-700" />
              <span>WhatsApp</span>
            </a>
          </div>

          <button
            onClick={() => onBookNow(room.id)}
            id="modal-select-and-book-btn"
            className="w-full sm:w-auto bg-[#B45309] hover:bg-[#92400E] text-white px-6 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition duration-200 flex items-center justify-center gap-2 cursor-pointer shadow-sm"
          >
            <span>{lang === "bn" ? "এখনই এই রুমটি বুকিং করুন" : "Book This Room Now"}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
}
