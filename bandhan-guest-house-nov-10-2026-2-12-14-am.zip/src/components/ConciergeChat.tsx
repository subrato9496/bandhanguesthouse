/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { MessageSquare, Send, X, Sparkles, Phone, HelpCircle } from "lucide-react";
import { receptionistReplies, hotelContact } from "../data";

interface ChatMessage {
  id: string;
  sender: "receptionist" | "guest";
  text: string;
  timestamp: string;
}

interface ConciergeChatProps {
  lang: "bn" | "en";
}

export default function ConciergeChat({ lang }: ConciergeChatProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initialize with welcome message on mount or language switch
  useEffect(() => {
    setMessages([
      {
        id: "welcome",
        sender: "receptionist",
        text: lang === "bn" ? receptionistReplies.welcome.bn : receptionistReplies.welcome.en,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      }
    ]);
  }, [lang]);

  // Scroll to bottom helper
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  const handleSendMessage = (textToSend: string) => {
    if (!textToSend.trim()) return;

    const guestId = `msg-guest-${Date.now()}`;
    const newGuestMsg: ChatMessage = {
      id: guestId,
      sender: "guest",
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    };

    setMessages((prev) => [...prev, newGuestMsg]);
    setInputText("");
    setIsTyping(true);

    // Dynamic pattern response logic
    setTimeout(() => {
      let replyWord = "default";
      const cleanedText = textToSend.toLowerCase();

      if (
        cleanedText.includes("room") ||
        cleanedText.includes("রুম") ||
        cleanedText.includes("ভাড়া") ||
        cleanedText.includes("ভাড়া") ||
        cleanedText.includes("rent") ||
        cleanedText.includes("tariff") ||
        cleanedText.includes("ac") ||
        cleanedText.includes("এসি")
      ) {
        replyWord = "rooms";
      } else if (
        cleanedText.includes("policy") ||
        cleanedText.includes("পলিসি") ||
        cleanedText.includes("১২") ||
        cleanedText.includes("12") ||
        cleanedText.includes("নিয়ম") ||
        cleanedText.includes("নিয়ম")
      ) {
        replyWord = "policy";
      } else if (
        cleanedText.includes("location") ||
        cleanedText.includes("ম্যাপ") ||
        cleanedText.includes("কোথায়") ||
        cleanedText.includes("কোথায়") ||
        cleanedText.includes("address") ||
        cleanedText.includes("ঠিকানা") ||
        cleanedText.includes("crp") ||
        cleanedText.includes("সিআরপি") ||
        cleanedText.includes("শিমুলতলা")
      ) {
        replyWord = "location";
      } else if (
        cleanedText.includes("ফোন") ||
        cleanedText.includes("যোগাযোগ") ||
        cleanedText.includes("contact") ||
        cleanedText.includes("phone") ||
        cleanedText.includes("নাম্বার") ||
        cleanedText.includes("কল") ||
        cleanedText.includes("whatsapp") ||
        cleanedText.includes("হোয়াটসঅ্যাপ")
      ) {
        replyWord = "contact";
      }

      const rawReply = (receptionistReplies as any)[replyWord] || receptionistReplies.default;
      const finalReplyText = lang === "bn" ? rawReply.bn : rawReply.en;

      const replyId = `msg-reply-${Date.now()}`;
      setMessages((prev) => [
        ...prev,
        {
          id: replyId,
          sender: "receptionist",
          text: finalReplyText,
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
        }
      ]);
      setIsTyping(false);
    }, 800);
  };

  const quickQuestionsBn = [
    { text: "রুম ভাড়া ও ১২ ঘণ্টার প্যাকেজ", q: "১২ ঘণ্টার প্যাকেজ ও রুমের ভাড়া কত?" },
    { text: "লোকেশন ও সিআরপি শিমুলতলা", q: "বন্ধন গেস্ট হাউসের সঠিক অবস্থান কোথায়?" },
    { text: "১২ ঘণ্টার বুকিং নীতিমালা", q: "১২ ঘণ্টার বুকিং নিয়মাবলী বিস্তারিত বলুন" },
    { text: "জরুরি যোগাযোগ হটলাইন", q: "সরাসরি যোগাযোগের ফোন নম্বর দিন" }
  ];

  const quickQuestionsEn = [
    { text: "Room Tariffs & 12h Stay", q: "What are the 12-hour stay rates?" },
    { text: "Location & CRP Shimultola", q: "Where is Bandhan Guest House located?" },
    { text: "12-Hour Stay Policy", q: "Please explain the 12-hour booking policy." },
    { text: "Direct Hotline", q: "What is your phone and WhatsApp number?" }
  ];

  const quickQuestions = lang === "bn" ? quickQuestionsBn : quickQuestionsEn;

  return (
    <>
      {/* Floating Action Button - Positioned safely above mobile bottom nav */}
      <button
        onClick={() => setIsOpen(true)}
        id="concierge-floating-trigger"
        className="fixed bottom-20 sm:bottom-6 right-4 sm:right-6 bg-[#B45309] hover:bg-[#92400E] text-[#FDFCF7] p-3.5 sm:p-4 rounded-full shadow-2xl flex items-center justify-center gap-2 group transition duration-300 z-40 cursor-pointer border border-amber-300/40"
        aria-label="Toggle Online Receptionist Chat"
      >
        <MessageSquare className="w-5 h-5 sm:w-6 sm:h-6" />
        <span className="hidden sm:inline text-xs sm:text-sm font-semibold whitespace-nowrap pl-1">
          {lang === "bn" ? "অনলাইন অ্যাসিস্ট্যান্স" : "Chat with us"}
        </span>
        <span className="absolute -top-1 -right-1 bg-emerald-500 w-3 h-3 rounded-full animate-ping pointer-events-none" />
        <span className="absolute -top-1 -right-1 bg-emerald-500 w-3 h-3 rounded-full pointer-events-none" />
      </button>

      {/* Floating Chat Modal Panel */}
      {isOpen && (
        <div 
          id="concierge-chat-panel"
          className="fixed bottom-20 sm:bottom-6 right-3 sm:right-6 w-[calc(100vw-24px)] sm:w-[410px] h-[520px] max-h-[80vh] bg-white border border-[#E7DDCB] shadow-2xl rounded-2xl flex flex-col z-50 overflow-hidden animate-fade-in-up"
        >
          {/* Header styling */}
          <div className="bg-[#1C1917] p-4 text-[#FDFCF7] flex items-center justify-between border-b border-[#E7DDCB]">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-[#B45309] flex items-center justify-center relative">
                <Sparkles className="w-4 h-4 text-yellow-300" />
                <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-[#1C1917]" />
              </div>
              <div>
                <h4 className="font-serif text-sm md:text-base font-semibold leading-none text-white">
                  {lang === "bn" ? "বন্ধন গেস্ট হাউস সহকারী" : "Bandhan Reception Desk"}
                </h4>
                <p className="text-[10px] text-amber-400 mt-1 font-mono uppercase tracking-wider">
                  {lang === "bn" ? "● সিআরপি, শিমুলতলা, সাভার" : "● CRP, Shimultola, Savar"}
                </p>
              </div>
            </div>
            
            <button
              onClick={() => setIsOpen(false)}
              className="text-stone-400 hover:text-white p-1 rounded-lg transition duration-150 cursor-pointer"
              aria-label="Close Chat"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Quick Contacts Bar */}
          <div className="bg-[#FAF8F5] px-4 py-2 border-b border-[#E7DDCB] text-[11px] text-stone-600 flex items-center justify-between gap-2 font-light">
            <span className="text-amber-900 bg-amber-100 rounded-md px-2 py-0.5 text-[10px] font-semibold">
              ফোন: {hotelContact.phone}
            </span>
            <div className="flex items-center gap-2">
              <a 
                href={`tel:${hotelContact.phone}`} 
                className="text-amber-800 hover:underline flex items-center gap-0.5 font-medium"
              >
                <Phone className="w-3 h-3" />
                <span>{lang === "bn" ? "কল" : "Call"}</span>
              </a>
              <span>•</span>
              <a 
                href={`https://wa.me/${hotelContact.whatsappClean}`}
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-emerald-700 hover:underline flex items-center gap-0.5 font-medium"
              >
                <span>WhatsApp</span>
              </a>
            </div>
          </div>

          {/* Messages scroll area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3.5 bg-[#FDFCF9]/60">
            {messages.map((msg) => (
              <div 
                key={msg.id} 
                className={`flex flex-col ${msg.sender === "guest" ? "items-end" : "items-start"}`}
              >
                <div 
                  className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-xs sm:text-[13px] leading-relaxed shadow-3xs whitespace-pre-line ${
                    msg.sender === "guest" 
                      ? "bg-[#B45309] text-white rounded-tr-xs" 
                      : "bg-white text-stone-900 border border-[#E7DDCB] rounded-tl-xs"
                  }`}
                >
                  {msg.text}
                </div>
                <span className="text-[9.5px] text-gray-400 mt-1 px-1 font-mono">
                  {msg.timestamp}
                </span>
              </div>
            ))}

            {isTyping && (
              <div className="flex items-center gap-1.5 p-3 bg-white border border-[#E7DDCB] rounded-2xl rounded-tl-xs w-20">
                <span className="w-1.5 h-1.5 bg-amber-700 rounded-full animate-bounce [animation-delay:-0.3s]" />
                <span className="w-1.5 h-1.5 bg-amber-700 rounded-full animate-bounce [animation-delay:-0.15s]" />
                <span className="w-1.5 h-1.5 bg-amber-700 rounded-full animate-bounce" />
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick Suggestion Pills */}
          <div className="px-3 py-2 bg-[#FAF8F5] border-t border-[#E7DDCB] flex gap-1.5 overflow-x-auto shrink-0">
            {quickQuestions.map((item, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(item.q)}
                className="text-[10px] bg-white border border-[#E7DDCB] hover:border-amber-600 text-stone-700 hover:text-amber-800 rounded-full px-2.5 py-1 whitespace-nowrap transition cursor-pointer"
              >
                {item.text}
              </button>
            ))}
          </div>

          {/* Input field Footer */}
          <div className="p-3 bg-white border-t border-[#E7DDCB] flex items-center gap-2">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSendMessage(inputText)}
              placeholder={lang === "bn" ? "প্রশ্ন বা মতামত লিখুন..." : "Type your inquiry..."}
              className="flex-1 bg-stone-50 border border-stone-200 rounded-xl px-3.5 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-amber-700 text-stone-800"
            />
            <button
              onClick={() => handleSendMessage(inputText)}
              className="bg-[#B45309] hover:bg-[#92400E] text-white p-2.5 rounded-xl cursor-pointer transition shadow-2xs shrink-0"
              aria-label="Send Message"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>

        </div>
      )}
    </>
  );
}
