/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { galleryPhotos } from "../data";
import { GalleryPhoto } from "../types";
import { Camera, Image as ImageIcon, Maximize2, X, ChevronLeft, ChevronRight } from "lucide-react";

interface PhotoGallerySectionProps {
  lang: "bn" | "en";
}

export default function PhotoGallerySection({ lang }: PhotoGallerySectionProps) {
  const [selectedCategory, setSelectedCategory] = useState<"all" | "rooms" | "lounge" | "amenities">("all");
  const [activePhotoIndex, setActivePhotoIndex] = useState<number | null>(null);

  const filteredPhotos = selectedCategory === "all" 
    ? galleryPhotos 
    : galleryPhotos.filter(p => p.category === selectedCategory);

  const activePhoto = activePhotoIndex !== null ? filteredPhotos[activePhotoIndex] : null;

  const handleNext = () => {
    if (activePhotoIndex === null) return;
    setActivePhotoIndex((activePhotoIndex + 1) % filteredPhotos.length);
  };

  const handlePrev = () => {
    if (activePhotoIndex === null) return;
    setActivePhotoIndex((activePhotoIndex - 1 + filteredPhotos.length) % filteredPhotos.length);
  };

  return (
    <section id="gallery-section" className="space-y-8 scroll-mt-20">
      
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-800 bg-[#FAF1E3] px-3.5 py-1 rounded-full uppercase tracking-wider">
            <Camera className="w-3.5 h-3.5" />
            <span>{lang === "bn" ? "আসল ফটো গ্যালারি" : "Authentic Photo Gallery"}</span>
          </div>
          <h3 className="font-serif text-2xl sm:text-3xl md:text-4xl font-bold text-stone-900 leading-tight">
            {lang === "bn" ? "বন্ধন গেস্ট হাউসের পরিচ্ছন্ন দৃশ্য" : "Visual Tour of Our Facilities"}
          </h3>
          <p className="text-stone-600 text-xs sm:text-sm">
            {lang === "bn" 
              ? "অতিথিদের জন্য প্রস্তুতকৃত বাস্তব রুম ও সার্বিক পরিবেশের স্থিরচিত্র।" 
              : "Authentic photographs of our verified rooms, comfortable bedding, and amenities."}
          </p>
        </div>

        {/* Filter buttons */}
        <div className="flex flex-wrap gap-1.5 sm:gap-2">
          {[
            { id: "all", labelBn: "সব ছবি", labelEn: "All Views" },
            { id: "rooms", labelBn: "রুমসমূহ", labelEn: "Suites & Rooms" },
            { id: "lounge", labelBn: "লবি ও রিসেপশন", labelEn: "Lobby & Entry" },
            { id: "amenities", labelBn: "সুবিধাসমূহ", labelEn: "Dining & Facilities" }
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id as any)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium transition cursor-pointer ${
                selectedCategory === cat.id
                  ? "bg-[#B45309] text-white shadow-xs"
                  : "bg-white text-stone-700 border border-[#E7DDCB] hover:bg-stone-100"
              }`}
            >
              {lang === "bn" ? cat.labelBn : cat.labelEn}
            </button>
          ))}
        </div>
      </div>

      {/* Photo Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredPhotos.map((photo, index) => (
          <div
            key={photo.id}
            onClick={() => setActivePhotoIndex(index)}
            className="group relative bg-stone-900 rounded-2xl overflow-hidden aspect-[4/3] cursor-pointer shadow-xs hover:shadow-lg transition-all duration-300 border border-[#E7DDCB]"
          >
            <img
              src={photo.imageUrl}
              alt={lang === "bn" ? photo.titleBn : photo.titleEn}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
            
            {/* Gradient Overlay with Captions */}
            <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity flex flex-col justify-end p-4">
              <div className="flex items-center justify-between text-white">
                <div>
                  <span className="text-[10px] text-amber-400 font-mono uppercase tracking-wider block">
                    {photo.category}
                  </span>
                  <h4 className="font-serif text-sm sm:text-base font-bold text-[#FDFCF7]">
                    {lang === "bn" ? photo.titleBn : photo.titleEn}
                  </h4>
                  <p className="text-[11px] text-stone-300 line-clamp-1 mt-0.5">
                    {lang === "bn" ? photo.captionBn : photo.captionEn}
                  </p>
                </div>

                <div className="w-8 h-8 rounded-full bg-white/20 backdrop-blur-xs flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity">
                  <Maximize2 className="w-4 h-4" />
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Lightbox Modal */}
      {activePhoto && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/90 backdrop-blur-md p-4 animate-fade-in"
          onClick={() => setActivePhotoIndex(null)}
        >
          <div 
            className="relative max-w-4xl w-full max-h-[90vh] flex flex-col items-center"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close Button */}
            <button
              onClick={() => setActivePhotoIndex(null)}
              className="absolute -top-12 right-0 text-white hover:text-amber-400 p-2 rounded-full cursor-pointer transition"
              aria-label="Close Lightbox"
            >
              <X className="w-6 h-6" />
            </button>

            {/* Main Lightbox Image */}
            <div className="relative w-full aspect-[16/10] sm:aspect-[16/9] rounded-2xl overflow-hidden bg-black shadow-2xl border border-stone-800">
              <img
                src={activePhoto.imageUrl}
                alt={lang === "bn" ? activePhoto.titleBn : activePhoto.titleEn}
                className="w-full h-full object-contain"
              />

              {/* Prev / Next controls */}
              <button
                onClick={handlePrev}
                className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/60 hover:bg-black/90 text-white flex items-center justify-center transition cursor-pointer"
                aria-label="Previous Photo"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
              <button
                onClick={handleNext}
                className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/60 hover:bg-black/90 text-white flex items-center justify-center transition cursor-pointer"
                aria-label="Next Photo"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            </div>

            {/* Bottom Caption */}
            <div className="w-full text-center text-white mt-3 space-y-1">
              <h4 className="font-serif text-lg font-bold">
                {lang === "bn" ? activePhoto.titleBn : activePhoto.titleEn}
              </h4>
              <p className="text-xs text-stone-300">
                {lang === "bn" ? activePhoto.captionBn : activePhoto.captionEn}
              </p>
            </div>
          </div>
        </div>
      )}

    </section>
  );
}
