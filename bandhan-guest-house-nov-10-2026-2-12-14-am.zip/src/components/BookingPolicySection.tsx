/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Clock, ShieldCheck, AlertCircle, CalendarCheck, FileCheck, PhoneCall } from "lucide-react";
import { hotelContact } from "../data";

interface BookingPolicySectionProps {
  lang: "bn" | "en";
}

export default function BookingPolicySection({ lang }: BookingPolicySectionProps) {
  return (
    <section id="policy-section" className="space-y-8 scroll-mt-20">
      
      {/* Section Title */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-800 bg-[#FAF1E3] px-3.5 py-1 rounded-full uppercase tracking-wider">
          <Clock className="w-3.5 h-3.5" />
          <span>{lang === "bn" ? "বুকিং নীতিমালা ও নিয়মাবলী" : "Booking Policy & Instructions"}</span>
        </div>
        
        <h3 className="font-serif text-2xl sm:text-3xl md:text-4xl font-bold text-stone-900 leading-tight">
          {lang === "bn" ? "স্বচ্ছ ও সুনির্দিষ্ট বুকিং নীতিমালা" : "Transparent & Clear Stay Guidelines"}
        </h3>
        
        <p className="text-stone-600 text-xs sm:text-sm md:text-base">
          {lang === "bn" 
            ? "অতিথিদের সুবিধার্থে এবং ঝামেলামুক্ত অবস্থানের জন্য আমাদের ১২ ঘণ্টার প্যাকেজ ও সময়সূচি।" 
            : "Designed to ensure a peaceful, hassle-free and comfortable stay for every guest at Savar."}
        </p>
      </div>

      {/* Primary Gold Banner - Explicitly verbatim Bengali quote as required */}
      <div className="relative overflow-hidden bg-gradient-to-br from-[#FAF1E3] via-[#F5E6CC] to-[#FAF1E3] border-2 border-[#D97706]/40 rounded-2xl md:rounded-3xl p-6 sm:p-8 md:p-10 shadow-sm">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center gap-6 justify-between">
          <div className="space-y-3 max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-[#B45309] text-white text-[11px] font-semibold px-3 py-1 rounded-full uppercase tracking-wider">
              <AlertCircle className="w-3.5 h-3.5" />
              <span>{lang === "bn" ? "মূল বুকিং নীতিমালা" : "Core 12-Hour Stay Rule"}</span>
            </div>

            <blockquote className="font-serif text-lg sm:text-xl md:text-2xl font-bold text-stone-950 leading-snug">
              {lang === "bn" ? (
                "\"প্রতিটি বুকিং ১২ ঘণ্টার জন্য নির্ধারিত। বুকিংয়ের ১২ ঘণ্টার মধ্যে অতিথি যতক্ষণ অবস্থান করুন না কেন, ভাড়ার কোনো পরিবর্তন হবে না। দিনের ও রাতের ভাড়া আলাদা।\""
              ) : (
                "\"Each booking is scheduled for 12 hours. Regardless of the duration of stay within 12 hours, the tariff remains unchanged. Day and night rates differ.\""
              )}
            </blockquote>

            <p className="text-stone-700 text-xs sm:text-sm leading-relaxed">
              {lang === "bn"
                ? "অর্থাৎ আপনি ১২ ঘণ্টার প্যাকেজে রুম নিলে নির্ধারিত সময়ের পূর্বে চলে গেলেও সম্পূর্ণ ১২ ঘণ্টার নির্ধারিত ভাড়াই প্রযোজ্য হবে। একইভাবে দিন ও রাতের ভাড়া পৃথকভাবে হিসাব করা হয়।"
                : "Tariff for each 12-hour stay package is fixed for the allocated slot regardless of early check-out. Day stay and overnight night stay carry separate verified tariffs."}
            </p>
          </div>

          <div className="bg-white/90 backdrop-blur-xs p-5 rounded-2xl border border-amber-300/80 shadow-xs shrink-0 w-full md:w-auto text-center space-y-2">
            <span className="text-[11px] uppercase font-bold text-amber-900 tracking-wider block">
              {lang === "bn" ? "সরাসরি বুকিং ও সহায়তা" : "Direct Hotline"}
            </span>
            <a 
              href={`tel:${hotelContact.phone}`}
              className="text-lg font-mono font-bold text-stone-900 block hover:text-[#B45309] transition"
            >
              {hotelContact.phone}
            </a>
            <span className="text-[10.5px] text-stone-600 font-semibold block">
              {lang === "bn" ? hotelContact.managerBn : hotelContact.managerEn}
            </span>
          </div>
        </div>
      </div>

      {/* Grid of Instructions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Check-in Instructions */}
        <div className="bg-white border border-[#E7DDCB] p-6 rounded-2xl shadow-xs space-y-3 hover:border-amber-400 transition-colors">
          <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-900 flex items-center justify-center">
            <CalendarCheck className="w-5 h-5" />
          </div>
          <h4 className="font-serif text-base font-bold text-stone-900">
            {lang === "bn" ? "চেক-ইন নির্দেশাবলী" : "Check-in Instructions"}
          </h4>
          <ul className="text-xs sm:text-sm text-stone-600 space-y-2 leading-relaxed">
            <li className="flex items-start gap-2">
              <span className="font-bold text-amber-700">•</span>
              <span><strong>{lang === "bn" ? "২৪/৭ যেকোনো সময়:" : "24/7 Any Time:"}</strong> {lang === "bn" ? "দিন বা রাত যেকোনো সময় উপস্থিত হয়ে চেক-ইন করতে পারবেন।" : "Check-in available at any hour upon arrival."}</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="font-bold text-amber-700">•</span>
              <span>{lang === "bn" ? "আগে থেকে রুম রিজার্ভেশন নিশ্চিত করার জন্য হোয়াটসঅ্যাপ বা ফোনে জানিয়ে রাখা সুবিধাজনক।" : "Advance notification via WhatsApp or call ensures fast key handover."}</span>
            </li>
          </ul>
        </div>

        {/* Check-out Instructions */}
        <div className="bg-white border border-[#E7DDCB] p-6 rounded-2xl shadow-xs space-y-3 hover:border-amber-400 transition-colors">
          <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-900 flex items-center justify-center">
            <Clock className="w-5 h-5" />
          </div>
          <h4 className="font-serif text-base font-bold text-stone-900">
            {lang === "bn" ? "চেক-আউট নির্দেশাবলী" : "Check-out Instructions"}
          </h4>
          <ul className="text-xs sm:text-sm text-stone-600 space-y-2 leading-relaxed">
            <li className="flex items-start gap-2">
              <span className="font-bold text-amber-700">•</span>
              <span><strong>{lang === "bn" ? "নমনীয় শিডিউল:" : "Flexible Shifts:"}</strong> {lang === "bn" ? "সকাল ৮:০০ টা থেকে রাত ৮:০০ টা পর্যন্ত আপনার ১২ ঘণ্টা স্লট অনুযায়ী চেক-আউট সম্পন্ন করা যায়।" : "Check-out takes place smoothly per your allocated 12-hour shift."}</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="font-bold text-amber-700">•</span>
              <span>{lang === "bn" ? "রুম ছাড়ার পূর্বে আপনার প্রয়োজনীয় ব্যাগপত্র ও ব্যক্তিগত জিনিসপত্র ভালো করে দেখে নিন।" : "Please double-check your personal belongings before room handover."}</span>
            </li>
          </ul>
        </div>

        {/* Guest Security & Identity Rules */}
        <div className="bg-white border border-[#E7DDCB] p-6 rounded-2xl shadow-xs space-y-3 hover:border-amber-400 transition-colors">
          <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-900 flex items-center justify-center">
            <FileCheck className="w-5 h-5" />
          </div>
          <h4 className="font-serif text-base font-bold text-stone-900">
            {lang === "bn" ? "নিরাপত্তা ও পরিচয়পত্র" : "Guest Security & Identity"}
          </h4>
          <ul className="text-xs sm:text-sm text-stone-600 space-y-2 leading-relaxed">
            <li className="flex items-start gap-2">
              <span className="font-bold text-amber-700">•</span>
              <span><strong>{lang === "bn" ? "আইডি কার্ড আবশ্যক:" : "Valid ID Required:"}</strong> {lang === "bn" ? "জাতীয় পরিচয়পত্র (NID), পাসপোর্ট বা ড্রাইভিং লাইসেন্সের কপি সাথে রাখতে হবে।" : "Original or photocopy of National ID or Passport required."}</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="font-bold text-amber-700">•</span>
              <span>{lang === "bn" ? "১০০% পারিবারিক ও ভদ্র পরিবেশ বজায় রাখতে আমরা কোনো অনৈতিক কার্যকলাপ বরদাশত করি না।" : "We maintain a 100% quiet, family-safe, and corporate-standard environment."}</span>
            </li>
          </ul>
        </div>

      </div>

    </section>
  );
}
