/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Phone, MessageSquare, Calendar, MapPin } from "lucide-react";
import { hotelContact } from "../data";

interface MobileBottomNavProps {
  lang: "bn" | "en";
  onBookClick: () => void;
}

export default function MobileBottomNav({ lang, onBookClick }: MobileBottomNavProps) {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-[#1C1917]/95 backdrop-blur-md border-t border-stone-800 px-3 py-2.5 sm:hidden shadow-2xl animate-fade-in-up">
      <div className="flex items-center justify-between gap-2 max-w-md mx-auto">
        
        {/* Direct Phone Call Button */}
        <a
          href={`tel:${hotelContact.phone}`}
          className="flex-1 flex flex-col items-center justify-center py-1.5 px-2 rounded-xl bg-stone-900 border border-stone-700/80 text-white hover:text-amber-400 transition-colors text-center active:scale-95"
          aria-label="Call Bandhan Guest House Manager Shuvo"
        >
          <Phone className="w-4 h-4 text-amber-500 mb-0.5" />
          <span className="text-[10px] font-medium leading-none font-sans">
            {lang === "bn" ? "শুভ (ম্যানেজার)" : "Shuvo (Mgr)"}
          </span>
          <span className="text-[8.5px] font-mono text-stone-400 mt-0.5">
            {hotelContact.phone}
          </span>
        </a>

        {/* WhatsApp Chat Button */}
        <a
          href={`https://wa.me/${hotelContact.whatsappClean}?text=${encodeURIComponent(
            lang === "bn"
              ? "আসসালামু আলাইকুম শুভ ভাই, আমি বন্ধন গেস্ট হাউস (সি.আর.পি)-এ রুম বুকিং ও ভাড়া সম্পর্কে জানতে চাই।"
              : "Hello Shuvo Bhai, I would like to inquire about booking a room at Bandhan Guest House (CRP)."
          )}`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 flex flex-col items-center justify-center py-1.5 px-2 rounded-xl bg-emerald-900/60 border border-emerald-600/60 text-emerald-100 hover:text-white transition-colors text-center active:scale-95"
          aria-label="WhatsApp Bandhan Guest House"
        >
          <MessageSquare className="w-4 h-4 fill-emerald-400 text-emerald-400 mb-0.5" />
          <span className="text-[10px] font-semibold leading-none font-sans">
            WhatsApp
          </span>
          <span className="text-[8.5px] font-mono text-emerald-300 mt-0.5">
            {hotelContact.phone}
          </span>
        </a>

        {/* Instant Booking Trigger Button */}
        <button
          onClick={onBookClick}
          className="flex-1.2 flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-[#B45309] text-white hover:bg-[#92400E] font-semibold text-xs transition-colors shadow-sm active:scale-95 cursor-pointer text-center"
          aria-label="Book Room Now"
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>{lang === "bn" ? "এখনই বুক করুন" : "Book Room"}</span>
        </button>

      </div>
    </div>
  );
}
