/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { MapPin, Navigation, Car, Compass, ExternalLink, Phone, ShieldCheck } from "lucide-react";
import { hotelContact } from "../data";

interface SavarMapProps {
  lang: "bn" | "en";
}

interface MapTargetPoint {
  id: string;
  nameBn: string;
  nameEn: string;
  x: number; // percentage width
  y: number; // percentage height
  type: "hotel" | "medical" | "poi";
  timeBn: string;
  timeEn: string;
  detailBn: string;
  detailEn: string;
}

export default function SavarMap({ lang }: SavarMapProps) {
  const [selectedPoint, setSelectedPoint] = useState<string>("hotel");

  const mapPoints: MapTargetPoint[] = [
    {
      id: "hotel",
      nameBn: "বন্ধন গেস্ট হাউস (সি.আর.পি)",
      nameEn: "Bandhan Guest House (CRP)",
      x: 48,
      y: 50,
      type: "hotel",
      timeBn: "প্রধান কেন্দ্র",
      timeEn: "Central Hub",
      detailBn: "সাভার আরিচা হাইওয়ে,সি.আর.পি,শিমুল্তলা,সাভার। (ক্যাপ্টেন সামাদ টাওয়ার, লিফট-৫, সাভার বাসস্ট্যান্ড সংলগ্ন)। যোগাযোগ: 01957203424 -শুভ (ম্যানেজার)।",
      detailEn: "Located on Savar Aricha Highway, CRP, Shimultola, Savar (Captain Samad Tower, Lift-5). Contact: 01957203424 - Shuvo (Manager)."
    },
    {
      id: "crp-center",
      nameBn: "সিআরপি সাভার (পক্ষাঘাত পুনর্বাসন কেন্দ্র)",
      nameEn: "CRP Savar Rehabilitation Center",
      x: 52,
      y: 35,
      type: "medical",
      timeBn: "হেঁটে ২ মিনিট (৩০০ মিটার)",
      timeEn: "2 mins walk (300 meters)",
      detailBn: "আন্তর্জাতিক মানের পুনর্বাসন ও চিকিৎসা কেন্দ্র। চিকিৎসার প্রয়োজনে আগত রোগী ও স্বজনদের থাকার জন্য আমাদের গেস্ট হাউস নিকটবর্তী।",
      detailEn: "Internationally renowned paralysis treatment center. Walking distance from our suites."
    },
    {
      id: "sriti-shoudho",
      nameBn: "জাতীয় স্মৃতিসৌধ",
      nameEn: "National Martyrs' Memorial",
      x: 25,
      y: 20,
      type: "poi",
      timeBn: "রিকশায় ৭ মিনিট (৩.৫ কিমি)",
      timeEn: "7 mins ride (3.5 km)",
      detailBn: "বাংলাদেশের স্বাধীনতা যুদ্ধের বীর শহীদদের স্মরণে নির্মিত জাতীয় স্মৃতিস্তম্ভ।",
      detailEn: "The nationwide historic war memorial monument with peaceful gardens and lakes."
    },
    {
      id: "ju-campus",
      nameBn: "জাহাঙ্গীরনগর বিশ্ববিদ্যালয়",
      nameEn: "Jahangirnagar University",
      x: 68,
      y: 36,
      type: "poi",
      timeBn: "গাড়িতে ৫ মিনিট (২.০ কিমি)",
      timeEn: "5 mins drive (2.0 km)",
      detailBn: "লাল শাপলার ঝিল ও অতিথি পাখির জন্য বিখ্যাত দেশের শীর্ষ আবাসিক বিশ্ববিদ্যালয়।",
      detailEn: "Bangladesh's premier scenic residential university famous for water lily lakes."
    },
    {
      id: "savar-bus-stand",
      nameBn: "সাভার বাজার ও বাসস্ট্যান্ড",
      nameEn: "Savar Bus Stand",
      x: 36,
      y: 72,
      type: "poi",
      timeBn: "৩ মিনিট দূরত্ব (৮০০ মিটার)",
      timeEn: "3 mins transit (800m)",
      detailBn: "সাভারের মূল বাণিজ্যিক মোড় ও আন্তঃজেলা দূরপাল্লার বাস ট্রানজিট।",
      detailEn: "Savar's main transit interchange connecting directly to Dhaka metropolis."
    }
  ];

  const currentPoint = mapPoints.find((p) => p.id === selectedPoint) || mapPoints[0];

  return (
    <div className="bg-[#FAF8F5] border border-[#E7DDCB] rounded-2xl sm:rounded-3xl p-6 sm:p-8 space-y-6" id="savar-map-section">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-800 bg-[#FAF1E3] px-3.5 py-1 rounded-full uppercase tracking-wider">
            <Compass className="w-3.5 h-3.5" />
            <span>{lang === "bn" ? "লোকেশন ও যাতায়াত গাইড" : "Location & Transit Guide"}</span>
          </div>
          <h3 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900 leading-tight">
            {lang === "bn" ? "সিআরপি ও সাভারের প্রাণকেন্দ্রে আমাদের অবস্থান" : "Prime Location at CRP, Shimultola, Savar"}
          </h3>
          <p className="text-stone-600 text-xs sm:text-sm">
            {lang === "bn"
              ? "সিআরপি, সাভার বাসস্ট্যান্ড, জাহাঙ্গীরনগর বিশ্ববিদ্যালয় ও স্মৃতিসৌধের সংলগ্ন নিরাপদ ঠিকানা।"
              : "Direct proximity to CRP Shimultola, Savar Bus Stand, Jahangirnagar University, and National Memorial."}
          </p>
        </div>

        {/* Google Maps External Button */}
        <a
          href={hotelContact.mapsUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 bg-stone-900 hover:bg-[#B45309] text-white px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer shadow-xs shrink-0"
        >
          <Navigation className="w-4 h-4 text-amber-400" />
          <span>{lang === "bn" ? "গুগল ম্যাপে ডিরেকশন দেখুন" : "Open in Google Maps"}</span>
          <ExternalLink className="w-3.5 h-3.5 opacity-80" />
        </a>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        
        {/* Selected Landmark Details Card */}
        <div className="lg:col-span-5 bg-white border border-[#E7DDCB] rounded-2xl p-6 flex flex-col justify-between space-y-6 shadow-xs">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full ${
                currentPoint.id === "hotel" 
                  ? "bg-amber-100 text-amber-900 border border-amber-300"
                  : "bg-stone-100 text-stone-700"
              }`}>
                {currentPoint.id === "hotel" ? (lang === "bn" ? "আমাদের গেস্ট হাউস" : "Our Guest House") : (lang === "bn" ? "আশেপাশের ল্যান্ডমার্ক" : "Nearby Landmark")}
              </span>
              <span className="text-xs font-mono font-semibold text-amber-800">
                {lang === "bn" ? currentPoint.timeBn : currentPoint.timeEn}
              </span>
            </div>

            <div>
              <h4 className="font-serif text-xl font-bold text-stone-900">
                {lang === "bn" ? currentPoint.nameBn : currentPoint.nameEn}
              </h4>
              <p className="text-stone-600 text-xs sm:text-sm mt-2 leading-relaxed">
                {lang === "bn" ? currentPoint.detailBn : currentPoint.detailEn}
              </p>
            </div>

            <div className="p-3 bg-[#FAF8F5] rounded-xl border border-stone-200/80 space-y-1 text-xs">
              <span className="font-semibold text-stone-900 block">{lang === "bn" ? "ঠিকানা ও যোগাযোগের বিবরণ:" : "Address & Contacts:"}</span>
              <p className="text-stone-700 text-[11px] font-medium leading-snug">
                {hotelContact.addressBn} ({hotelContact.landmarkBn})
              </p>
              <div className="pt-1 flex flex-col sm:flex-row gap-1 sm:gap-3 text-stone-800 font-mono text-[11px]">
                <span>{hotelContact.managerBn}</span>
                <span className="hidden sm:inline">•</span>
                <span>হোয়াটসঅ্যাপ: <strong>{hotelContact.phone}</strong></span>
              </div>
            </div>
          </div>

          {/* Quick Select Buttons */}
          <div className="space-y-2 pt-2 border-t border-stone-100">
            <span className="text-[11px] text-stone-500 font-medium block">
              {lang === "bn" ? "গুরুত্বপূর্ণ স্থান নির্বাচন করুন:" : "Select Landmark to Preview:"}
            </span>
            <div className="flex flex-wrap gap-1.5">
              {mapPoints.map((pt) => (
                <button
                  key={pt.id}
                  onClick={() => setSelectedPoint(pt.id)}
                  className={`text-xs px-2.5 py-1 rounded-lg transition cursor-pointer ${
                    selectedPoint === pt.id
                      ? "bg-[#B45309] text-white font-semibold"
                      : "bg-stone-100 hover:bg-stone-200 text-stone-700"
                  }`}
                >
                  {lang === "bn" ? pt.nameBn.split("(")[0] : pt.nameEn}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Interactive Schematic Savar Map View */}
        <div className="lg:col-span-7 bg-[#1C1917] rounded-2xl overflow-hidden p-6 relative min-h-[340px] flex flex-col justify-between border border-stone-800 text-white shadow-inner">
          
          {/* Subtle Grid & Map Route Background */}
          <div className="absolute inset-0 opacity-15 pointer-events-none bg-[radial-gradient(#d97706_1px,transparent_1px)] [background-size:16px_16px]" />
          
          {/* Highway vector representation */}
          <div className="absolute inset-x-8 top-1/2 -translate-y-1/2 h-4 bg-stone-800/80 border-y border-stone-700/80 rounded-full flex items-center justify-between px-4">
            <span className="text-[9px] font-mono text-stone-400 uppercase tracking-widest hidden sm:inline">
              ← সাভার বাসস্ট্যান্ড (Dhaka)
            </span>
            <span className="text-[9px] font-mono text-amber-500 uppercase tracking-widest font-semibold">
              ঢাকা-আরিচা মহাসড়ক (Dhaka-Aricha Highway)
            </span>
            <span className="text-[9px] font-mono text-stone-400 uppercase tracking-widest hidden sm:inline">
              স্মৃতিসৌধ / আরিচা →
            </span>
          </div>

          <div className="relative z-10 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
              <span className="font-mono text-amber-400 text-[11px]">
                {lang === "bn" ? "সাভার শিমুলতলা অঞ্চল ম্যাপ" : "Savar Shimultola Area Radar"}
              </span>
            </div>
            <span className="text-[10px] text-stone-400 font-mono">
              23.8510° N, 90.2600° E
            </span>
          </div>

          {/* Interactive Pins on Map */}
          <div className="relative z-10 w-full h-48 my-auto">
            {mapPoints.map((pt) => {
              const isSelected = selectedPoint === pt.id;
              const isHotel = pt.id === "hotel";

              return (
                <button
                  key={pt.id}
                  onClick={() => setSelectedPoint(pt.id)}
                  style={{ left: `${pt.x}%`, top: `${pt.y}%` }}
                  className={`absolute -translate-x-1/2 -translate-y-1/2 transition-transform duration-200 cursor-pointer group flex flex-col items-center ${
                    isSelected ? "scale-115 z-30" : "scale-100 z-20 hover:scale-110"
                  }`}
                  aria-label={pt.nameEn}
                >
                  <div className={`p-2 rounded-xl flex items-center justify-center shadow-lg transition-all ${
                    isHotel 
                      ? "bg-[#B45309] text-white ring-4 ring-amber-400/40" 
                      : isSelected 
                      ? "bg-amber-500 text-stone-950 ring-2 ring-white" 
                      : "bg-stone-800 text-stone-300 hover:bg-stone-700"
                  }`}>
                    <MapPin className="w-4 h-4" />
                  </div>

                  <span className={`text-[9.5px] mt-1 font-semibold whitespace-nowrap px-1.5 py-0.5 rounded-md shadow-xs ${
                    isSelected 
                      ? "bg-amber-400 text-stone-950 font-bold" 
                      : "bg-stone-900/90 text-stone-300 border border-stone-800"
                  }`}>
                    {lang === "bn" ? pt.nameBn.split("(")[0] : pt.nameEn}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="relative z-10 flex flex-col sm:flex-row items-center justify-between gap-2 pt-3 border-t border-stone-800 text-[11px] text-stone-400">
            <span>{lang === "bn" ? "ম্যাপে পিনগুলোতে ক্লিক করে দূরত্ব ও বিবরণ দেখুন" : "Click pins to view transit duration & details"}</span>
            <a
              href={hotelContact.mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-amber-400 hover:underline flex items-center gap-1 font-medium"
            >
              <span>{lang === "bn" ? "গুগল ম্যাপে আসল লোকেশন" : "Direct Google Maps Pin"}</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>

        </div>

      </div>

    </div>
  );
}
