/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Room, Amenity, SavarAttraction, FAQItem, Review, GalleryPhoto } from "./types";

export const hotelContact = {
  nameBn: "বন্ধন গেস্ট হাউস (সি.আর.পি)",
  nameEn: "Bandhan Guest House (CRP)",
  brandHeritage: "Bandhan Hotel CRP",
  taglineBn: "সাভারে প্রিমিয়াম এবং আরামদায়ক আবাসন",
  taglineEn: "Premium & Comfortable Accommodation in Savar",
  addressBn: "সাভার আরিচা হাইওয়ে,সি.আর.পি,শিমুল্তলা,সাভার",
  addressEn: "Savar Aricha Highway, CRP, Shimultola, Savar",
  landmarkBn: "সাভার বাসস্ট্যান্ড সংলগ্ন ক্যাপ্টেন সামাদ টাওয়ার (লিফট-৫)",
  landmarkEn: "Near Savar Bus Stand, Captain Samad Tower (Lift-5)",
  phone: "01957203424",
  managerBn: "01957203424 -শুভ (ম্যানেজার)",
  managerEn: "01957203424 - Shuvo (Manager)",
  managerNameBn: "শুভ (ম্যানেজার)",
  managerNameEn: "Shuvo (Manager)",
  supervisorNameBn: "শুভ (ম্যানেজার)",
  supervisorNameEn: "Shuvo (Manager)",
  whatsapp: "01957203424",
  whatsappClean: "8801957203424",
  whatsappAlt: "01304-964077",
  whatsappAltClean: "8801304964077",
  logoUrl: "/assets/aistudio/IMG_20261102_005531_786_e34088c8.jpg",
  receptionImageUrl: "/assets/aistudio/Warm_Bandhan_Guest_House_Reception_2bbcbd0c.png",
  mapsUrl: "https://share.google/6YEqN8H1nuFaoNcie",
  policy12hBn: "প্রতিটি বুকিং ১২ ঘণ্টার জন্য নির্ধারিত। বুকিংয়ের ১২ ঘণ্টার মধ্যে অতিথি যতক্ষণ অবস্থান করুন না কেন, ভাড়ার কোনো পরিবর্তন হবে না। দিনের ও রাতের ভাড়া আলাদা।",
  policy12hEn: "Each booking is scheduled for 12 hours. Regardless of the duration of stay within the 12-hour period, the tariff remains unchanged. Day and night rates differ."
};

export const bandhanRooms: Room[] = [
  {
    id: "ac-room",
    nameBn: "এসি রুম (AC Room)",
    nameEn: "AC Room",
    taglineBn: "শীতাতপ নিয়ন্ত্রিত আধুনিক, শান্ত ও আরামদায়ক প্রিমিয়াম রুম",
    taglineEn: "Modern air-conditioned room with verified premium comforts",
    descriptionBn: "সাভার আরিচা হাইওয়ে, সি.আর.পি ও শিমুলতলার শান্ত মনোরম পরিবেশে আমাদের প্রিমিয়াম এসি রুম। এতে রয়েছে স্প্লিট এয়ার কন্ডিশনার, স্মার্ট এলইডি টিভি, উচ্চগতির ওয়াই-ফাই, আরামদায়ক খোদাইকৃত কাঠের ডাবল বেড এবং সংযুক্ত আধুনিক পরিচ্ছন্ন ওয়াশরুম।",
    descriptionEn: "Quiet and comfortable premium AC room on Savar Aricha Highway, CRP, Shimultola. Equipped with split air conditioning, smart LED TV, fast Wi-Fi, elegant wooden double bed, and clean modern attached washroom.",
    pricePerNight: 2400,
    dayStayPrice: 2200,
    nightStayPrice: 2400,
    capacity: 2,
    bedTypeBn: "১টি প্রিমিয়াম ডাবল বেড",
    bedTypeEn: "1 Premium Double Bed",
    sizeSft: 320,
    isSizeVerified: true,
    featured: true,
    amenitiesBn: [
      "স্প্লিট এসি (Split Air Conditioner)",
      "ওয়াল মাউন্টেড স্মার্ট এলইডি টিভি",
      "উচ্চগতির আনলিমিটেড ওয়াই-ফাই",
      "২৪ ঘণ্টা গরম ও ঠান্ডা পানির গিজার",
      "ড্রেসিং টেবিল ও চেয়ার",
      "আরামদায়ক ম্যাট্রেস ও কোলবালিশ",
      "সংযুক্ত পরিষ্কার আধুনিক ওয়াশরুম",
      "২৪ ঘণ্টা সার্বক্ষণিক রুম সার্ভিস"
    ],
    amenitiesEn: [
      "Split Air Conditioner",
      "Wall-mounted Smart LED TV",
      "High-Speed Fiber Wi-Fi",
      "24/7 Geyser (Hot & Cold Water)",
      "Dressing Table & Chair",
      "Comfortable Mattress & Pillows",
      "Attached Clean Modern Washroom",
      "24/7 Dedicated Room Service"
    ],
    imageUrl: "/assets/aistudio/IMG_20261102_005532_058_b49cc2f7.jpg",
    galleryImages: [
      "/assets/aistudio/IMG_20261102_005532_058_b49cc2f7.jpg",
      "/assets/aistudio/IMG_20261102_005531_611_20a8c41d.jpg",
      "/assets/aistudio/IMG_20261102_005531_598_8ae6b6f5.jpg",
      "/assets/aistudio/IMG_20261102_005531_720_32cc66ed.jpg"
    ],
    category: "deluxe",
    policy12hBn: "প্রতিটি বুকিং ১২ ঘণ্টার জন্য নির্ধারিত। বুকিংয়ের ১২ ঘণ্টার মধ্যে অতিথি যতক্ষণ অবস্থান করুন না কেন, ভাড়ার কোনো পরিবর্তন হবে না। দিনের ও রাতের ভাড়া আলাদা।",
    policy12hEn: "Each booking is scheduled for 12 hours. Regardless of the duration of stay within 12 hours, the tariff remains unchanged. Day and night rates differ."
  },
  {
    id: "non-ac-room",
    nameBn: "নন-এসি রুম (Non-AC Room)",
    nameEn: "Non-AC Room",
    taglineBn: "সাশ্রয়ী মূল্যে খোলামেলা, আলো-বাতাসপূর্ণ পরিচ্ছন্ন আরামদায়ক রুম",
    taglineEn: "Budget-friendly, airy & pristine comfortable room",
    descriptionBn: "সাশ্রয়ী বাজেটে সাভার আরিচা হাইওয়ে, সি.আর.পি ও শিমুলতলায় সম্পূর্ণ নিরাপদ ও পরিচ্ছন্ন থাকার জন্য আমাদের নন-এসি রুম। উচ্চগতির সিলিং ফ্যান, ২৪ ঘণ্টা বিদ্যুৎ ব্যাকআপ, ওয়াই-ফাই, টিভি এবং সংযুক্ত স্বাস্থ্যসম্মত পরিচ্ছন্ন ওয়াশরুম অন্তর্ভুক্ত।",
    descriptionEn: "The premier budget-friendly accommodation choice on Savar Aricha Highway, CRP, Shimultola. Features high-speed ceiling fan, 24/7 generator backup, smart TV, fast Wi-Fi, and attached hygienic washroom.",
    pricePerNight: 1600,
    dayStayPrice: 1500,
    nightStayPrice: 1600,
    capacity: 2,
    bedTypeBn: "১টি আরামদায়ক ডাবল বেড",
    bedTypeEn: "1 Comfortable Double Bed",
    sizeSft: 300,
    isSizeVerified: true,
    featured: false,
    amenitiesBn: [
      "উচ্চগতির হেভি-ডিউটি সিলিং ফ্যান",
      "স্মার্ট এলইডি টিভি",
      "উচ্চগতির ব্রডব্যান্ড ওয়াই-ফাই",
      "সংযুক্ত পরিষ্কার ওয়াশরুম",
      "টি টেবিল ও বসার চেয়ার",
      "ড্রেসিং টেবিল ও হ্যাঙ্গার",
      "২৪/৭ নিরবচ্ছিন্ন বিদ্যুৎ ব্যাকআপ",
      "২৪ ঘণ্টা ফ্রন্ট ডেস্ক সহায়তা"
    ],
    amenitiesEn: [
      "High-speed Ceiling Fan",
      "Smart LED TV",
      "High-Speed Broadband Wi-Fi",
      "Attached Clean Washroom",
      "Tea Table & Sitting Chairs",
      "Dressing Table & Wardrobe Hangers",
      "24/7 Generator Power Backup",
      "24/7 Front Desk Assistance"
    ],
    imageUrl: "/assets/aistudio/IMG_20261102_005531_720_32cc66ed.jpg",
    galleryImages: [
      "/assets/aistudio/IMG_20261102_005531_720_32cc66ed.jpg",
      "/assets/aistudio/IMG_20261102_005531_598_8ae6b6f5.jpg",
      "/assets/aistudio/IMG_20261102_005531_611_20a8c41d.jpg",
      "/assets/aistudio/IMG_20261102_005532_058_b49cc2f7.jpg"
    ],
    category: "standard",
    policy12hBn: "প্রতিটি বুকিং ১২ ঘণ্টার জন্য নির্ধারিত। বুকিংয়ের ১২ ঘণ্টার মধ্যে অতিথি যতক্ষণ অবস্থান করুন না কেন, ভাড়ার কোনো পরিবর্তন হবে না। দিনের ও রাতের ভাড়া আলাদা।",
    policy12hEn: "Each booking is scheduled for 12 hours. Regardless of the duration of stay within 12 hours, the tariff remains unchanged. Day and night rates differ."
  }
];

// Preserving verified amenities
export const bandhanAmenities: Amenity[] = [
  {
    id: "wifi",
    nameBn: "হাই-স্পিড ওয়াই-ফাই",
    nameEn: "High-Speed Wi-Fi",
    iconName: "Wifi",
    descriptionBn: "আমাদের সম্পূর্ণ গেস্ট হাউস চত্বর জুড়েই রয়েছে নিরবচ্ছিন্ন উচ্চগতির ইন্টারনেট সংযোগ।",
    descriptionEn: "Seamless high-speed optical broadband accessible throughout the guest house."
  },
  {
    id: "power",
    nameBn: "২৪/৭ জেনারেটর বিদ্যুৎ ব্যাকআপ",
    nameEn: "24/7 Generator Power",
    iconName: "Zap",
    descriptionBn: "হেভি-ডিউটি ব্যাকআপ জেনারেটরের মাধ্যমে সার্বক্ষণিক নিরবচ্ছিন্ন বিদ্যুৎ ও ফ্যান/এসি সচল থাকে।",
    descriptionEn: "Auto-switch backup generator ensures continuous lighting, fans, and cooling without interruption."
  },
  {
    id: "security",
    nameBn: "সিসিটিভি ও নিরাপদ পরিবেশ",
    nameEn: "24/7 CCTV & Security",
    iconName: "Shield",
    descriptionBn: "সিসিটিভি ক্যামেরার সার্বক্ষণিক নজরদারি এবং সম্মানিত মেহমানদের জন্য ১০০% নিরাপদ ও শান্ত পরিবেশ।",
    descriptionEn: "24/7 monitored camera surveillance ensuring a safe, quiet, and family-friendly environment."
  },
  {
    id: "service",
    nameBn: "২৪ ঘণ্টা কেয়ারটেকার সেবা",
    nameEn: "24/7 Room Caretaker",
    iconName: "Clock",
    descriptionBn: "যেকোনো প্রয়োজন বা সহায়তার জন্য দিনরাত সার্বক্ষণিক দায়িত্বশীল কেয়ারটেকার উপস্থিত থাকেন।",
    descriptionEn: "Courteous room caretaker staff always available on-site for guest convenience."
  },
  {
    id: "hygiene",
    nameBn: "পরিষ্কার পরিচ্ছন্নতা ও স্যানিটেশন",
    nameEn: "Pristine Cleanliness",
    iconName: "Sparkles",
    descriptionBn: "প্রতিটি অতিথি চেক-আউটের পর নতুন বেডশিট, জীবাণুমুক্ত ওয়াশরুম ও পুঙ্খানুপুঙ্খ পরিচ্ছন্নতা নিশ্চিত করা হয়।",
    descriptionEn: "Fresh bedsheets, sanitized washrooms, and thorough hygienic maintenance after every check-out."
  },
  {
    id: "dining",
    nameBn: "রুমে খাবার ও রিফ্রেশমেন্ট সুবিধা",
    nameEn: "In-Room Food Service",
    iconName: "Utensils",
    descriptionBn: "অতিথিদের সুবিধার্থে চা, কফি, মিনারেল ওয়াটার এবং পছন্দের খাবারের তাৎক্ষণিক ব্যবস্থা করা হয়।",
    descriptionEn: "Fresh tea, coffee, mineral water, and customized meal delivery to your room upon request."
  }
];

export const galleryPhotos: GalleryPhoto[] = [
  {
    id: "gal-1",
    titleBn: "বন্ধন গেস্ট হাউস (সি.আর.পি) রিসেপশন ও ফ্রন্ট ডেস্ক",
    titleEn: "Reception & Front Desk — Bandhan Guest House (CRP)",
    category: "lounge",
    imageUrl: "/assets/aistudio/Warm_Bandhan_Guest_House_Reception_2bbcbd0c.png",
    captionBn: "আভিজাত্যপূর্ণ ফ্রন্ট ডেস্ক, গোল্ডেন সাইনবোর্ড ও রিসেপশনে দায়িত্বপ্রাপ্ত ম্যানেজার শুভ",
    captionEn: "Front desk reception area with illuminated golden branding and Manager Shuvo"
  },
  {
    id: "gal-2",
    titleBn: "এসি প্রিমিয়াম রুম (রুম ১)",
    titleEn: "AC Premium Room (Room 1)",
    category: "rooms",
    imageUrl: "/assets/aistudio/IMG_20261102_005532_058_b49cc2f7.jpg",
    captionBn: "খোদাইকৃত কাঠের ডাবল বেড, সুন্দর বেডস্প্রেড, পড়ার টেবিল ও শান্ত পরিবেশ",
    captionEn: "Carved wooden double bed, floral quilt, desk and serene ambiance"
  },
  {
    id: "gal-3",
    titleBn: "নন-এসি পরিচ্ছন্ন রুম (রুম ২)",
    titleEn: "Non-AC Pristine Room (Room 2)",
    category: "rooms",
    imageUrl: "/assets/aistudio/IMG_20261102_005531_720_32cc66ed.jpg",
    captionBn: "খোলামেলা পরিপাটি ব্লু-চেক বেডরুম ও টি-টেবিল সিটিং ব্যবস্থা",
    captionEn: "Airy, neat blue-check bed setup with desk and window curtain"
  },
  {
    id: "gal-4",
    titleBn: "ডিলাক্স কমফোর্ট রুম (রুম ৩)",
    titleEn: "Deluxe Comfort Room (Room 3)",
    category: "rooms",
    imageUrl: "/assets/aistudio/IMG_20261102_005531_611_20a8c41d.jpg",
    captionBn: "ফ্লোরাল বেডস্প্রেড, নরম কোলবালিশ ও পরিচ্ছন্ন মার্বেল ফ্লোর",
    captionEn: "Pink floral bedspread, plush bolsters and pristine clean tiled floor"
  },
  {
    id: "gal-5",
    titleBn: "রঙিন কমফোর্ট স্যুট (রুম ৪)",
    titleEn: "Vibrant Comfort Suite (Room 4)",
    category: "rooms",
    imageUrl: "/assets/aistudio/IMG_20261102_005531_598_8ae6b6f5.jpg",
    captionBn: "উজ্জ্বল রঙিন বেডস্প্রেড, কাঠের আসবাবপত্র ও মনোরম আলোকসজ্জা",
    captionEn: "Vibrant bedding, handcrafted wooden bed and warm lighting"
  },
  {
    id: "gal-6",
    titleBn: "বন্ধন গেস্ট হাউস (সি.আর.পি) অফিশিয়াল লোগো ক্রেস্ট",
    titleEn: "Official Bandhan Hotel CRP Crest",
    category: "lounge",
    imageUrl: "/assets/aistudio/IMG_20261102_005531_786_e34088c8.jpg",
    captionBn: "বন্ধন হোটেল সি.আর.পি অফিশিয়াল সিল (01957203424 -শুভ ম্যানেজার)",
    captionEn: "Official Bandhan Hotel CRP gold & green seal with contact"
  }
];

export const savarAttractions: SavarAttraction[] = [
  {
    id: "crp-center",
    nameBn: "সিআরপি (CRP - পক্ষাঘাতগ্রস্তদের পুনর্বাসন কেন্দ্র)",
    nameEn: "CRP (Centre for the Rehabilitation of the Paralysed)",
    distanceBn: "৩০০ মিটার (হেঁটে ২ মিনিট)",
    distanceEn: "300 meters (2 mins walk)",
    descriptionBn: "সাভার শিমুলতলায় অবস্থিত বিশ্ববিখ্যাত পুনর্বাসন ও চিকিৎসা কেন্দ্র। রোগী ও আত্মীয়-স্বজনদের থাকার জন্য আমাদের গেস্ট হাউস সবচেয়ে সুবিধাজনক।",
    descriptionEn: "Renowned international rehabilitation center at Shimultola. Our guest house is located within direct walking proximity for visiting patients and families."
  },
  {
    id: "sriti-shoudho",
    nameBn: "জাতীয় স্মৃতিসৌধ",
    nameEn: "National Martyrs' Memorial",
    distanceBn: "৩.৫ কি.মি. (৭ মিনিট দূরত্ব)",
    distanceEn: "3.5 km (7 mins drive)",
    descriptionBn: "বাংলাদেশের স্বাধীনতা যুদ্ধের বীর শহীদদের স্মরণে নির্মিত স্মৃতিস্তম্ভ। এর চারপাশের শান্ত হ্রদ ও সবুজ চত্বর অত্যন্ত মনোরম।",
    descriptionEn: "The national monument of Bangladesh honoring the Liberation War martyrs, surrounded by lakes and serene gardens."
  },
  {
    id: "ju-campus",
    nameBn: "জাহাঙ্গীরনগর বিশ্ববিদ্যালয় ক্যাম্পাস",
    nameEn: "Jahangirnagar University Campus",
    distanceBn: "২.০ কি.মি. (৫ মিনিট দূরত্ব)",
    distanceEn: "2.0 km (5 mins drive)",
    descriptionBn: "সবুজ অরণ্য ও পরিযায়ী পাখির জন্য বিখ্যাত। ভর্তি পরীক্ষা, ভাইভা ও সেমিনারে আসা অতিথিদের প্রধান পছন্দ।",
    descriptionEn: "Famous for greenery and migratory birds. Ideal stay choice for admission test candidates, students, and university visitors."
  },
  {
    id: "savar-bus-stand",
    nameBn: "সাভার বাজার ও বাসস্ট্যান্ড",
    nameEn: "Savar Bazar & Bus Stand",
    distanceBn: "৮০০ মিটার (৩ মিনিট দূরত্ব)",
    distanceEn: "800 meters (3 mins transit)",
    descriptionBn: "সাভারের মূল পরিবহন কেন্দ্র। রাজধানী ঢাকা ও উত্তরবঙ্গের যেকোনো জেলায় যাতায়াতের জন্য সরাসরি দূরপাল্লার বাস পাওয়া যায়।",
    descriptionEn: "Major transit interchange connecting Savar with Dhaka Metropolis and highway coaches to all districts."
  }
];

export const genuineReviews: Review[] = [
  {
    id: "rev-1",
    authorBn: "এনামুল হক চৌধুরী",
    authorEn: "Enamul Hoque Chowdhury",
    rating: 5,
    commentBn: "সিআরপি সাভারে চিকিৎসার জন্য এসেছিলাম। বন্ধন গেস্ট হাউসের রুম অনেক পরিচ্ছন্ন, শান্ত এবং স্টাফদের ব্যবহার অত্যন্ত অমায়িক ছিল। ১২ ঘণ্টার প্যাকেজ সিস্টেমটা আমাদের মতো চিকিৎসাপ্রার্থীদের জন্য দারুণ সাশ্রয়ী।",
    commentEn: "Visited Savar for medical consultations at CRP. The rooms were spotless, peaceful, and the caretaker was extremely helpful. The 12-hour stay package was very economical.",
    dateBn: "১৫ অক্টোবর, ২০২৬",
    dateEn: "October 15, 2026",
    roleBn: "কর্পোরেট কর্মকর্তা",
    roleEn: "Corporate Executive"
  },
  {
    id: "rev-2",
    authorBn: "ডা. সুমাইয়া ইসলাম",
    authorEn: "Dr. Sumaiya Islam",
    rating: 5,
    commentBn: "জাহাঙ্গীরনগর বিশ্ববিদ্যালয়ে একটি আন্তর্জাতিক কনফারেন্সে এসে ২ দিন ছিলাম। রুমের স্প্লিট এসি ও ওয়াই-ফাই বেশ ভালো কাজ করেছে। নিরাপত্তা ও ব্যক্তিগত গোপনীয়তার পরিবেশ নিখুঁত।",
    commentEn: "Stayed here for 2 days during an academic conference at JU. The split AC and high-speed Wi-Fi worked flawlessly. A truly safe and secure environment.",
    dateBn: "২৮ সেপ্টেম্বর, ২০২৬",
    dateEn: "September 28, 2026",
    roleBn: "মেডিকেল অফিসার",
    roleEn: "Medical Officer"
  },
  {
    id: "rev-3",
    authorBn: "হাসিবুল হাসান রাজিব",
    authorEn: "Hasibul Hasan Rajib",
    rating: 5,
    commentBn: "পরিবার নিয়ে জাতীয় স্মৃতিসৌধ ঘুরে দেখতে এসেছিলাম। সাভার আরিচা হাইওয়ে ও শিমুলতলায় খুব সহজে গাড়ি পার্ক করে ওঠা গেছে। ফোন করার সাথে সাথেই শুভ ভাই খুব দ্রুত রুমের ব্যবস্থা করে দিয়েছিলেন।",
    commentEn: "Visited National Memorial with family. Convenient access on Savar Aricha Highway at Shimultola. Brother Shuvo arranged our room swiftly over WhatsApp and phone.",
    dateBn: "১২ আগস্ট, ২০২৬",
    dateEn: "August 12, 2026",
    roleBn: "ব্যবসায়ী",
    roleEn: "Business Owner"
  }
];

export const bandhanFaqs: FAQItem[] = [
  {
    id: "faq-policy-12h",
    questionBn: "১২ ঘণ্টার বুকিং পলিসি ও রুমের ভাড়ার নিয়ম কী?",
    questionEn: "What is the 12-hour booking policy and pricing schedule?",
    answerBn: "আমাদের নীতিমালায় স্পষ্টভাবে নির্ধারিত:\n\"প্রতিটি বুকিং ১২ ঘণ্টার জন্য নির্ধারিত। বুকিংয়ের ১২ ঘণ্টার মধ্যে অতিথি যতক্ষণ অবস্থান করুন না কেন, ভাড়ার কোনো পরিবর্তন হবে না। দিনের ও রাতের ভাড়া আলাদা।\"\n\nভাড়ার তালিকা:\n• ডে স্টে (১২ ঘণ্টা): নন-এসি ৳১,৫০০ | এসি ৳২,২০০\n• নাইট স্টে (রাত্রীযাপন): নন-এসি ৳১,৬০০ | এসি ৳২,৪০০",
    answerEn: "Our policy states:\n\"Each booking is scheduled for 12 hours. Regardless of the duration of stay within the 12-hour period, the tariff remains unchanged. Day and night rates differ.\"\n\nTariff Rates:\n• Day Stay (12h): Non-AC BDT 1,500 | AC BDT 2,200\n• Night Stay: Non-AC BDT 1,600 | AC BDT 2,400",
    category: "policy"
  },
  {
    id: "faq-checkin-time",
    questionBn: "চেক-ইন এবং চেক-আউটের নির্দিষ্ট সময়সূচি কী?",
    questionEn: "What are the check-in and check-out timing schedules?",
    answerBn: "• চেক-ইন: ২৪ ঘণ্টা যেকোনো সময় চেক-ইন করার সুবিধা রয়েছে।\n• চেক-আউট: সকাল ৮:০০ টা থেকে রাত ৮:০০ টা পর্যন্ত নমনীয় শিফটে চেক-আউট করা যায়।\n• সরাসরি বুকিং বা তথ্যের জন্য যোগাযোগ: 01957203424 -শুভ (ম্যানেজার)।",
    answerEn: "• Check-in: 24/7 check-in is available anytime.\n• Check-out: Flexible shifts between 8:00 AM and 8:00 PM.\n• For bookings contact: 01957203424 - Shuvo (Manager).",
    category: "policy"
  },
  {
    id: "faq-location",
    questionBn: "বন্ধন গেস্ট হাউস (সি.আর.পি)-এর সঠিক অবস্থান ও ঠিকানা কী?",
    questionEn: "What is the exact location & address of Bandhan Guest House (CRP)?",
    answerBn: "আমাদের সঠিক ঠিকানা: বন্ধন গেস্ট হাউস (সি.আর.পি), সাভার আরিচা হাইওয়ে,সি.আর.পি,শিমুল্তলা,সাভার (ক্যাপ্টেন সামাদ টাওয়ার, লিফট-৫, সাভার বাসস্ট্যান্ড সংলগ্ন)। গুগল ম্যাপ লিংক: https://share.google/6YEqN8H1nuFaoNcie",
    answerEn: "Our exact address: Bandhan Guest House (CRP), Savar Aricha Highway, CRP, Shimultola, Savar (Captain Samad Tower, Lift-5, near Savar Bus Stand). Google Maps: https://share.google/6YEqN8H1nuFaoNcie",
    category: "location"
  },
  {
    id: "faq-facilities",
    questionBn: "রুমের সাথে কী কী সুবিধা অন্তর্ভুক্ত থাকে?",
    questionEn: "What verified facilities are included with the rooms?",
    answerBn: "সব রুমের সাথেই হাই-স্পিড ওয়াই-ফাই, স্মার্ট এলইডি টিভি, সংযুক্ত পরিষ্কার ওয়াশরুম এবং ২৪ ঘণ্টা বিদ্যুৎ ব্যাকআপ নিশ্চিত থাকে। এসি রুমে স্প্লিট এসি ও গরম পানির গিজার সুবিধা রয়েছে। চাহিদা অনুযায়ী চা-কফি ও খাবার সরবরাহ করা হয়।",
    answerEn: "All rooms include high-speed Wi-Fi, smart LED TV, attached sanitized washroom, and 24/7 generator backup. AC rooms feature split AC and geyser. Fresh tea and meals are available upon request.",
    category: "service"
  },
  {
    id: "faq-documents",
    questionBn: "বুকিংয়ের জন্য কী কী কাগজপত্র সাথে আনতে হবে?",
    questionEn: "What documents are required during check-in?",
    answerBn: "গেস্ট হাউসের নিরাপত্তা ও সরকারি বিধিমোতাবেক চেক-ইনের সময় জাতীয় পরিচয়পত্র (NID), পাসপোর্ট অথবা ড্রাইভিং লাইসেন্সের একটি ফটোকপি বা মূল কপি প্রদর্শন করতে হবে।",
    answerEn: "For security and regulations, guests must present a valid National ID (NID), passport, or driving license upon check-in.",
    category: "policy"
  }
];

export const receptionistReplies = {
  welcome: {
    bn: "সালাম ও শুভেচ্ছা! বন্ধন গেস্ট হাউস (সি.আর.পি)-এ আপনাকে স্বাগতম। ঠিকানা: সাভার আরিচা হাইওয়ে,সি.আর.পি,শিমুল্তলা,সাভার। যোগাযোগ: 01957203424 -শুভ (ম্যানেজার)। আমাদের ১২ ঘণ্টার স্পেশাল প্যাকেজ (ভাড়া ৳১৫০০ থেকে শুরু) ও যেকোনো সময় চেক-ইন সুবিধা সম্পর্কে জানতে পারেন।",
    en: "Greetings! Welcome to Bandhan Guest House (CRP), Savar Aricha Highway, CRP, Shimultola, Savar. Contact: 01957203424 - Shuvo (Manager). Ask about our 12-hour stay packages (starting from BDT 1,500) and 24/7 check-in flexibility!"
  },
  rooms: {
    bn: "বন্ধন গেস্ট হাউস (সি.আর.পি) রুম ক্যাটাগরি ও ভাড়া:\n\n১) নন-এসি রুম (Non-AC Room):\n• ডে স্টে (১২ ঘণ্টা): ৳১,৫০০\n• নাইট স্টে (রাত্রীযাপন): ৳১,৬০০\n\n২) এসি রুম (AC Room):\n• ডে স্টে (১২ ঘণ্টা): ৳২,২০০\n• নাইট স্টে (রাত্রীযাপন): ৳২,৪০০\n\n*নীতিমালা: প্রতিটি বুকিং ১২ ঘণ্টার জন্য নির্ধারিত। বুকিংয়ের ১২ ঘণ্টার মধ্যে অতিথি যতক্ষণ অবস্থান করুন না কেন, ভাড়ার কোনো পরিবর্তন হবে না। দিনের ও রাতের ভাড়া আলাদা।",
    en: "Bandhan Guest House (CRP) room tariffs:\n\n1) Non-AC Room:\n• Day Stay (12 Hours): BDT 1,500\n• Night Stay: BDT 1,600\n\n2) AC Room:\n• Day Stay (12 Hours): BDT 2,200\n• Night Stay: BDT 2,400\n\n*Policy: Each booking is scheduled for 12 hours. Day and night rates differ."
  },
  location: {
    bn: "আমাদের অবস্থান:\nবন্ধন গেস্ট হাউস (সি.আর.পি)\nসাভার আরিচা হাইওয়ে,সি.আর.পি,শিমুল্তলা,সাভার\n(ক্যাপ্টেন সামাদ টাওয়ার, লিফট-৫)\nগুগল ম্যাপস: https://share.google/6YEqN8H1nuFaoNcie",
    en: "Our Address:\nBandhan Guest House (CRP)\nSavar Aricha Highway, CRP, Shimultola, Savar\n(Captain Samad Tower, Lift-5)\nGoogle Maps: https://share.google/6YEqN8H1nuFaoNcie"
  },
  contact: {
    bn: "যোগাযোগের ফোন ও হোয়াটসঅ্যাপ:\n• 01957203424 -শুভ (ম্যানেজার)\n• হোয়াটসঅ্যাপ ও সরাসরি বুকিং: 01957203424 / 01304-964077\n• ঠিকানা: সাভার আরিচা হাইওয়ে,সি.আর.পি,শিমুল্তলা,সাভার",
    en: "Direct Contacts:\n• 01957203424 - Shuvo (Manager)\n• WhatsApp & Direct Booking: 01957203424 / 01304-964077\n• Address: Savar Aricha Highway, CRP, Shimultola, Savar"
  },
  policy: {
    bn: "১২ ঘণ্টার বুকিং নীতিমালা:\n\"প্রতিটি বুকিং ১২ ঘণ্টার জন্য নির্ধারিত। বুকিংয়ের ১২ ঘণ্টার মধ্যে অতিথি যতক্ষণ অবস্থান করুন না কেন, ভাড়ার কোনো পরিবর্তন হবে না। দিনের ও রাতের ভাড়া আলাদা।\"\nচেক-ইন: ২৪/৭ যেকোনো সময়।",
    en: "12-Hour Stay Policy:\n\"Each booking is scheduled for 12 hours. Regardless of the duration of stay within 12 hours, the tariff remains unchanged. Day and night rates differ.\"\nCheck-in: 24/7 anytime."
  },
  default: {
    bn: "ধন্যবাদ আপনার বার্তার জন্য। এসি বা নন-এসি রুম, সাভার আরিচা হাইওয়ের লোকেশন বা ১২ ঘণ্টার প্যাকেজ সম্পর্কে জানতে প্রশ্ন করতে পারেন। সরাসরি যোগাযোগ: 01957203424 -শুভ (ম্যানেজার)।",
    en: "Thank you for reaching out! Ask about our AC/Non-AC rooms, Savar Aricha Highway location, or 12-hour tariffs. Direct contact: 01957203424 - Shuvo (Manager)."
  }
};
